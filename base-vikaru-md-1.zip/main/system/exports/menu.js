require("../../settings/config.js")
const { hidetext } = require("./hidetext.js")

const textMenu =
`> ❏ *\`ʀᴜʟᴇs    :\`*
     • ᴅɪʟᴀʀᴀɴɢ sᴘᴀᴍ / ᴄᴀʟʟ / ᴠᴄ
     • ᴛᴀᴍʙᴀʜᴋᴀɴ ʙᴏᴛ ᴋᴇ ɢᴄ? ɪᴢɪɴ

> ❏ *\`ɴᴏᴛᴇ     :\`*
     • ʙᴏᴛ ᴏғғ? ɴᴏ ɪɴᴛᴇʀɴᴇᴛ
     • ʙᴇʀɪ ᴊᴇᴅᴀ ᴘᴀᴅᴀ ᴄᴍᴅ ʙᴏᴛ

> ❏ *\`ᴍᴇɴᴜ     :\`*
     • ${hidetext}ᴅɪsᴘᴘᴀʏ ʟɪsᴛ ᴍᴇɴᴜ


 ☰  *\`ᴏᴛʜᴇʀ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /sc
> ▸ /list
> ▸ /say
> ▸ /ping
> ▸ /store
> ▸ /owner
> ▸ /runtime


 ☰  *\`ᴀɪ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /ai
> ▸ /simi
> ▸ /autoai
> ▸ /ilustrasi
> ▸ /generate
> ▸ /imgnsfw


 ☰  *\`ᴄᴏɴᴠᴇʀᴛᴇʀ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /sticker
> ▸ /bratimg
> ▸ /bratvid
> ▸ /spotifyd
> ▸ /ttmp4
> ▸ /ttmp3
> ▸ /facebook
> ▸ /instagram


 ☰  *\`sᴇᴀʀᴄʜ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /news
> ▸ /sound
> ▸ /spotifys
> ▸ /pinterest
> ▸ /ytsearch


 ☰  *\`ᴀɴɪᴍᴇ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /sfw
> ▸ /nsfw
> ▸ /anime
> ▸ /voice
> ▸ /cecan
> ▸ /cosplay


 ☰  *\`ᴛᴏᴏʟs ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /hd
> ▸ /get
> ▸ /rvo
> ▸ /clear
> ▸ /tourl
> ▸ /virtex
> ▸ /ssweb
> ▸ /iptracking


 ☰  *\`ɢʀᴜᴘ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /mute
> ▸ /silent
> ▸ /add
> ▸ /kick
> ▸ /kickall
> ▸ /kickme
> ▸ /promote
> ▸ /demote
> ▸ /tagall
> ▸ /hidetag
> ▸ /poll
> ▸ /getppgc
> ▸ /setppgc
> ▸ /setnamegc
> ▸ /setdeskgc
> ▸ /group
> ▸ /linkgc
> ▸ /antilink
> ▸ /antitoxic
> ▸ /welcome
> ▸ /pushkontak


☰  *\`sʏsᴛᴇᴍ ᴍᴇɴᴜ\`*
∘╌────────────────╌∘
> ▸ /upsw
> ▸ /upch
> ▸ /save
> ▸ /prefix
> ▸ /setmenu
> ▸ /autoread
> ▸ /autoreadsw
> ▸ /anticall
> ▸ /setnamebot
> ▸ /setppbot 
> ▸ /block
> ▸ /unblock
> ▸ /getcase
> ▸ /addmod
> ▸ /delmod
> ▸ /listmod
> ▸ /addprem
> ▸ /delprem
> ▸ /listprem
> ▸ /joingc
> ▸ /leavegc
> ▸ /listgroup
> ▸ /addlimit
> ▸ /ceklimit
> ▸ /public
> ▸ /self
> ▸ /delete


${global.footer}`

exports.textMenu = textMenu

// Refreshing File After Recode/Editing
const fs = require("fs")
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log()
console.log(`› [ ${chalk.black(chalk.bgBlue(' Update Files '))} ] - ${__filename}`)
delete require.cache[file]
require(file)
})