require('./../settings/config.js');
const {
     default: makeWASocket,
     DisconnectReason,
     makeInMemoryStore,
     jidDecode,
     jidNormalizedUser,
     makeCacheableSignalKeyStore,
     proto,
     getContentType,
     useMultiFileAuthState,
     getAggregateVotesInPollMessage,
     downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
     smsg,
     isUrl,
     generateMessageTag,
     getBuffer,
     getSizeMedia,
     fetchJson,
     await,
     sleep
} = require('./myfunction.js');
const {
     Boom
} = require('@hapi/boom');
const fs = require('fs');
const path = require('path');
const pino = require('pino');
const chalk = require('chalk');
const readline = require("readline");
const FileType = require('file-type');
const NodeCache = require('node-cache');
const PhoneNumber = require('awesome-phonenumber');

const store = makeInMemoryStore({
     logger: pino().child({
          level: 'silent',
          stream: 'store'
     })
});

if (!global.startdata || !(global.startdata instanceof Array)) {
     global.startdata = [];
}

async function multisession(connId, sessionPath) {
     const {
          state,
          saveCreds
     } = await await useMultiFileAuthState(
          path.join(__dirname, '../../session/' + sessionPath),
          pino({
               level: 'silent'
          })
     );

     const cache = new NodeCache();
     const waSocket = makeWASocket({
          logger: pino({
               level: 'silent'
          }),
          printQRInTerminal: false,
          mobile: process.argv.includes('--mobile'),
          connectTimeoutMs: 60000,
          defaultQueryTimeoutMs: 0,
          keepAliveIntervalMs: 10000,
          emitOwnEvents: true,
          fireInitQueries: true,
          generateHighQualityLinkPreview: true,
          syncFullHistory: true,
          markOnlineOnConnect: true,
          auth: {
               creds: state.creds,
               keys: makeCacheableSignalKeyStore(
                    state.keys,
                    pino({
                         level: 'fatal'
                    }).child({
                         level: 'fatal'
                    })
               ),
          },
          browser: ['Ubuntu', 'Chrome', '20.0.04'],
          version,
          patchMessageBeforeSending: (msg) => {
               if (msg.buttonsMessage || msg.templateMessage || msg.listMessage) {
                    return {
                         viewOnceMessage: {
                              message: {
                                   messageContextInfo: {
                                        deviceListMetadataVersion: 2,
                                        deviceListMetadata: {},
                                   },
                                   ...msg,
                              },
                         },
                    };
               }
               return msg;
          },
          getMessage: async (message) => {
               const jid = jidNormalizedUser(message.remoteJid);
               const loadedMessage = await store.loadMessage(jid, message.id);
               return loadedMessage?.message || '';
          },
          markOnlineOnConnect: true,
          generateHighQualityLinkPreview: true,
          msgRetryCounterCache: cache,
     });

     if (!waSocket.authState.creds.registered) {
          let retryCount = 0;
          const maxRetries = 3;

          while (retryCount < maxRetries) {
               try {
                    await sleep(3000); // Tunggu sebelum mencoba
                    let pairing = await waSocket.requestPairingCode(sessionPath);
                    let code = pairing?.match(/.{1,4}/g)?.join("-") || pairing;
                    global.pairingcode = code;
                    global.startdata.push({
                         session: sessionPath,
                         code: code
                    });
                    console.log(`Pairing code for ${sessionPath}: ${code}`);
               } catch (error) {
                    console.error(`Failed to get pairing code for ${sessionPath}:`, error);
                    retryCount++;
                    console.log(`coba melakukan reconnect, percobaan ke ${retryCount}`);
                    await sleep(2000); // Tunggu sebelum mencoba lagi
               }
          }

          if (retryCount === maxRetries) {
               console.log(`Percobaan reconnect melebihi batas maksimum untuk ${sessionPath}.`);
               return; // Menghentikan eksekusi jika semua percobaan gagal
          }
     }



     waSocket.public = true;
     store.bind(waSocket.ev);

     waSocket.ev.on('messages.upsert', async (update) => {
          try {
               const msg = update.messages[0];
               if (msg.message) {
                    require('./../vikaru.js')(waSocket, msg, store);
               }
          } catch (error) {
               console.error(error);
          }
     });

     waSocket.ev.on('connection.update', (update) => {
          const {
               connection,
               receivedPendingNotifications,
               lastDisconnect
          } = update;

          try {
               if (connection == 'connecting') {
                    console.log(`[ Starting Bot ] - Connecting To WhatsApp Server... for ${sessionPath}`);
               } else if (connection === "open") {
                    console.log(`[ Connected To ] - ${waSocket.user.id} for ${sessionPath}`);
                    waSocket.sendMessage(sessionPath + '@s.whatsapp.net', {
                         text: global.notify
                    });
                    if (receivedPendingNotifications) {
                         console.log(`[ Waiting Chat ] - Waiting for incoming message... for ${sessionPath}`);
                    }
               } else if (connection === "close") {
                    let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
                    if (reason === DisconnectReason.badSession) {
                         console.log(`[ Disconnected ] - Bad Session File, Please Delete Session and Pairing Again for ${sessionPath}`);
                         process.exit();
                    } else if (reason === DisconnectReason.connectionClosed) {
                         console.log(`[ Reconnecting ] - Connection Closed... for ${sessionPath}`);
                         multisession(sessionPath);
                    } else if (reason === DisconnectReason.connectionLost) {
                         console.log(`[ Reconnecting ] - Connection Lost From Server... for ${sessionPath}`);
                         multisession(sessionPath);
                    } else if (reason === DisconnectReason.connectionReplaced) {
                         console.log(`[ Disconnected ] - Connection Replaced, Another New Session Opened for ${sessionPath}`);
                         process.exit();
                    } else if (reason === DisconnectReason.loggedOut) {
                         console.log(`[ Disconnected ] - Device Logged Out, Delete "${sessionPath}" Folder and Pairing Again. for ${sessionPath}`);
                         fs.rmSync(`./session/${sessionPath}`, {
                              recursive: true
                         });
                         multisession(sessionPath);
                    } else if (reason === DisconnectReason.restartRequired) {
                         console.log(`[ Reconnecting ] - Restart Required... for ${sessionPath}`);
                         multisession(sessionPath);
                    } else if (reason === DisconnectReason.timedOut) {
                         console.log(`[ Reconnecting ] - Connection TimedOut... for ${sessionPath}`);
                         multisession(sessionPath);
                    } else {
                         console.log(`[ Reconnecting ] - Unknown DisconnectReason: ${reason}|${connection} for ${sessionPath}`);
                         multisession(sessionPath);
                    }
               }
          } catch (e) {
               console.error("Error connection update", e)
          }
     });

     waSocket.decodeJid = (jid) => {
          if (!jid) return jid
          if (/:\d+@/gi.test(jid)) {
               let decode = jidDecode(jid) || {}
               return decode.user && decode.server && decode.user + '@' + decode.server || jid
          } else return jid
     };

     waSocket.getName = (jid, withoutContact = false) => {
          id = waSocket.decodeJid(jid)
          withoutContact = waSocket.withoutContact || withoutContact
          let v
          if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
               v = store.contacts[id] || {}
               if (!(v.name || v.subject)) v = waSocket.groupMetadata(id) || {}
               resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
          })
          else v = id === '0@s.whatsapp.net' ? {
                    id,
                    name: 'WhatsApp'
               } : id === waSocket.decodeJid(waSocket.user.id) ?
               waSocket.user :
               (store.contacts[id] || {})
          return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
     };

     waSocket.sendText = (jid, text, quoted = '', options) => waSocket.sendMessage(jid, {
          text: text,
          ...options
     }, {
          quoted
     });

     waSocket.ev.on('creds.update', saveCreds);

     return waSocket
};

module.exports = {
     multisession,
     startdata: global.startdata
}

// Refreshing File After Recode/Editing
let file = require.resolve(__filename)
fs.watchFile(file, () => {
     fs.unwatchFile(file)
     console.log()
     console.log(`› [ ${chalk.black(chalk.bgBlue(" Update Files "))} ] ▸ ${__filename}`)
     delete require.cache[file]
     require(file)
})