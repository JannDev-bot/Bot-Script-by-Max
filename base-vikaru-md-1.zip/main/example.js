/*

 Here is an example of a message sending code that you can use in "cmd.js"
 
 */

//━━━━━━━━━━[ EXAMPLE CMD ]━━━━━━━━━━//

// Reaction + read
case "reaction": {
await vikaru.sendMessage(m.chat, { react: { text: "☑️", key: m.key }});
} break;



// Default message
case "text1": {
await vikaru.sendMessage(m.chat, { text: "Text" });
} break;



// Default message + read
case "text2": {
vikaru.sendMessage(m.chat, { text: "Text", key: m.key });
} break;



// Default message + quoted
case "text3": {
await vikaru.sendMessage(m.chat, { text: "Text" }, { quoted: m });
} break;



// Default message + forward 
case "text4": {
await vikaru.sendMessage(m.chat, { text: "Text", contextInfo: { forwardingScore: 1, isForwarded: true }});
} break;



// Default message + quoted + read
case "text5": {
vikaru.sendMessage(m.chat, { text: "Text", key: m.key }, { quoted: m });
} break;



// Default message + quoted + read + forward
case "text6": {
vikaru.sendMessage(m.chat, { text: "Text", contextInfo: { forwardingScore: 10, isForwarded: true }, key: m.key }, { quoted: m });
} break;



// Simple message + quoted + read
case "reply1": {
m.reply("Text");
} break;




// Simple message + quoted + read
case "reply2": {
reply(m.chat, "Text"); // m.chat / m.sender
} break;



// Image + link + simple message 
case "only": {
only("Admin only")
} break



// Mention group participants
case "mention": {
const user1 = "6289508899033"
const user2 = "0"
await vikaru.sendMessage(m.chat, {
    text: `Hi, @${user1}, @${user2} How are you`,
    mentions: ["6289508899033@s.whatsapp.net", "0@s.whatsapp.net"]
})
} break;



// Edit message
case "loading": {
async function loading () {
var bar = [
"> 《 [▒▒▒▒▒▒▒▒▒▒▒▒] 》0%",
"> 《 [█▒▒▒▒▒▒▒▒▒▒▒] 》10%",
"> 《 [████▒▒▒▒▒▒▒▒] 》30%",
"> 《 [███████▒▒▒▒▒] 》50%",
"> 《 [██████████▒▒] 》80%",
"> 《 [████████████] 》100%",
"> ⓘ `loading-complete!`"
]
const { key } = await vikaru.sendMessage(m.chat, {text: "> ⓘ `loading...`"}, { quoted: m })

for (let i = 0; i < bar.length; i++) {
await vikaru.sendMessage(m.chat, {text: bar[i], edit: key })
}
}
loading();
} break;



// Sticker message
case "sticker": {
await vikaru.sendMessage(m.chat, { sticker: fs.readFileSync("./main/media/sticker/tes.webp")});
} break;



// Image + caption + quoted
case "image": {
await vikaru.sendMessage(m.chat, { image: fs.readFileSync("./main/media/image/menu.jpg"), mimetype: "image/jpeg", caption: `Text` }, { quoted: m });
} break;



// Image + link + newsletter + caption + quoted
case "link": {
await vikaru.sendMessage(m.chat, { text: "Caption",
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: newsletter, // 6289508899033@s.whatsapp.net
    newsletterName: "Vikaru-Md | © Max",
    serverMessageId: -1
},
                externalAdReply: {
                    title: `Title`,
                    body: `Description`,
                    //thumbnailUrl: imgUrl,
                    //thumbnailUrl: imgUrlRandom,
                    thumbnail: imgFile,
                    //thumbnailUrl: ppUrl,
                    //sourceUrl: `https://wa.me/6289513484928`,
                    sourceUrl: `${global.sosmed}`,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
}, { userJid: m.chat, quoted: m })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
} break;



// Image + link + doc image + newsletter + caption + quoted
case "linkimage": {
vikaru.sendMessage(m.chat, {
    document: fs.readFileSync("./main/media/document/menu.txt"),
    fileName: "File name",
    mimetype: 'image/png',
    jpegThumbnail: fs.readFileSync("./main/media/image/menu.jpg"), 
    contextInfo: {
        mentionedJid: [m.sender], 
        isForwarded: true,
        externalAdReply: {
        title: "Title", 
        body: "Description", 
         thumbnail: fs.readFileSync("./main/media/image/menu.jpg"),
        sourceUrl: "Link",
       mediaType: 1,
        renderLargerThumbnail: true
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: newsletter,
            serverMessageId: null,
            newsletterName: "Channel Name"
        },
    },
  caption: "Caption",
  footer: "Footer",
  headerType: 1,
  viewOnce: true
}, { quoted: m })
} break



// Document message + caption + quoted
case "document1": {
await vikaru.sendMessage(m.chat, { document: fs.readFileSync("./main/media/document/tes.txt"), caption: `Text` }, { quoted: m });
} break;



// Document message + image + caption + quoted
case "document2": {
vikaru.sendMessage(m.chat, {
    document: fs.readFileSync("./main/media/document/tes.txt"),
    fileName: global.jpegfile,
    mimetype: 'application/msword',
    jpegThumbnail: fs.readFileSync("./main/media/image/menu.jpg"), 
    contextInfo: {
        mentionedJid: [m.sender], 
        isForwarded: true,
        /*forwardedNewsletterMessageInfo: {
            newsletterJid: global.ids,
            serverMessageId: null,
            newsletterName: global.nems
        },*/
    },
    caption: "tes",
  footer: "tes",
  headerType: 1,
  viewOnce: true
}, { quoted: m })
} break;



// Pdf message + caption + quoted
case "pdf": {
await vikaru.sendMessage(m.chat, { document: fs.readFileSync("./main/media/document/tes.txt"), mimetype: 'application/pdf', fileName: "File name", caption: `Text` }, { quoted: m });
} break;



// Video message + caption + quoted
case "video": {
await vikaru.sendMessage(m.chat, { video: fs.readFileSync("./main/media/video/tes.mp4"), mimetype: "video/mp4", fileName: "tes.mp4", caption: `Text` }, { quoted: m });
} break;



// Audio message + quoted
case "audio": {
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/menu.mp3"), mimetype: "audio/mpeg" }, { quoted: m });
} break;



// Voice note message + quoted
case "vn": {
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/menu.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
} break;



// Contact Message + quoted
case "contact": {
const contact =  {
displayName: "Display Name", contacts: [{displayName: "Contact Name", vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:dcodemaxz\nORG:© Developer\nitem1.TEL;waid=6289508899033:6289508899033\nitem1.X-ABLabel:Dont Spam!\nADR;TYPE=HOME:;;Jakarta;;Indonesia;;Indonesia\nEMAIL;TYPE=My Email:dcodemaxz@gmail.com\nURL:https://linktr.ee/dcodemaxz\nEND:VCARD`}]
};
await vikaru.sendMessage(m.chat, {contacts: contact }, { quoted: m })
} break;



// Location message / share location
case "location": {
await vikaru.sendMessage(m.chat, { location: { degreesLatitude: -75.1002446, degreesLongitude: 123.34634, }}, { quoted: m });
} break;



// Polling 1
case "polling1": {
await sendPoll(m.chat, 'Title', ['Poll A', 'Poll B', 'Poll C'], 1); // 2 : More than 1 choice
} break;



// Polling 2
case "polling2": {
await vikaru.sendMessage(m.chat, {
poll: {
name: "Title",
values: ["Poll A", "Poll B", "Poll C"],
selectableCount: 2 // 2 : More than 1 choice
}
}, { quoted: m })
} break;



// Catalog + newsletter + quoted
case "catalog": {
const msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
      contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: { // Newsletter 
            newsletterJid: newsletter, // 6289508899033@s.whatsapp.net
            newsletterName: "Vikaru-Md | © Max", 
            serverMessageId: -1
		    }, // The divider
	businessMessageForwardInfo: { businessOwnerJid: vikaru.decodeJid(vikaru.user.id) },
	forwardingScore: 256,
            externalAdReply: {  
                title: "Vikaru-Md", 
                thumbnailUrl: "https://telegra.ph/file/8089ac60dd17836dcd0bf.jpg", 
                sourceUrl: "https://chat.whatsapp.com/JfpGsd5GPh5EzvRVjm54tx",
                mediaType: 1,
                renderLargerThumbnail: false
            }
          }, 
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: `*Hello, @${m.sender.replace(/@.+/g, '')}!*\nHere is a list of products!`
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
          text: "© Max"
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          hasMediaAttachment: false
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            { // Button url
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: "Button url"
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: "Title\n",
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/9106a72b183e27a81a02d.jpg" } }, { upload: vikaru.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"Open","url":"https://wa.me/6289508899033","merchant_url":"https://wa.me/6289508899033"}`
                  }
                  ]
              })
            }, // The divider
            { // Button copy
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: "Button copy"
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: "Title\n",
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/9106a72b183e27a81a02d.jpg" } }, { upload: vikaru.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                  name: "cta_copy",
                  buttonParamsJson: `{\"display_text\":\"Copy\",\"id\":\".menu\",\"copy_code\":\"text\"}`
                  }
                  ]
              })
            }, // The divider
            /*{ // Button reply ( This button cannot be used in groups. error! )
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: "Button reply"
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: "Judul\n",
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/9106a72b183e27a81a02d.jpg" } }, { upload: vikaru.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                  name: "quick_reply",
                  buttonParamsJson: `{"display_text":"Select","id":".menu"}`
                  }
                  ]
              })
            }*/ // The divider
          ]
        })
      })
    }
  }
}, { userJid: m.chat, quoted: m })
vikaru.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
} break;