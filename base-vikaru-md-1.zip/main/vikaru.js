/*
<•━━━━━━━━[ SOURCE CODE ]━━━━━━━━━•>

 • Developer : Maxz
 • Contact   : https://linktr.ee/dcodemaxz

<•━━━━━━━━━━━━━━━━━━━━━━━━━━━━━•>

 • [ NOTE ]
 - Thank you for supporting the developer by purchasing this script.
 - Please read the "© dcodemaxz" before using this script!
 
*/


require("./settings/config.js");
const {
smsg, getGroupAdmins, formatp, resize, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, sendFile, jsonformat, delay, format, logic, appenTextMessage, generateProfilePicture, parseMention, getRandom, pickRandom
} = require("./system/myfunction.js")

const {
remini
} = require("./system/remini.js")

const { downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, RevikaruectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediavikaruInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisvikaruectReason, WASocket, getStream, WAProto, isBaileys, AnyMessageContent, fetchLatestBaileysVersion, templateMessage } = require("@whiskeysockets/baileys")

const fs = require("fs")
const os = require('os')
const util = require("util")
const pino = require('pino')
const chalk = require("chalk")
const axios = require("axios")
const { exec } = require("child_process")
const moment = require("moment-timezone")
const PhoneNumber = require('awesome-phonenumber');
const errorCache = new Map();
const fatalErrorCache = new Map();

// Main
module.exports = vikaru = async (vikaru, m, chatUpdate, mek, store, setting, welcome) => {
try {
const body = (
(m.mtype === "conversation" && m.message.conversation) ||
(m.mtype === "imageMessage" && m.message.imageMessage.caption) ||
(m.mtype === "documentMessage" && m.message.documentMessage.caption) ||
(m.mtype === "videoMessage" && m.message.videoMessage.caption) ||
(m.mtype === "extendedTextMessage" && m.message.extendedTextMessage.text) ||
(m.mtype === "buttonsResponseMessage" && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === "templateButtonReplyMessage" && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === "conversation" && m.message.conversation) ||
(m.mtype === "imageMessage" && m.message.imageMessage.caption) ||
(m.mtype === "documentMessage" && m.message.documentMessage.caption) ||
(m.mtype === "videoMessage" && m.message.videoMessage.caption) ||
(m.mtype === "extendedTextMessage" && m.message.extendedTextMessage.text) ||
(m.mtype === "buttonsResponseMessage" && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === "templateButtonReplyMessage" && m.message.templateButtonReplyMessage.selectedId)
) : '';

// Variable Base
const budy = (typeof m.text === "string") ? m.text : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (vikaru.user.id.split(":")[0]+"@s.whatsapp.net" || vikaru.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split("@")[0]
const pushname = m.pushName || `${senderNumber}`
const botNumber = await vikaru.decodeJid(vikaru.user.id)
const isBot = botNumber.includes(senderNumber)
const itsMe = m.sender == botNumber ? true : false
const quoted = m.quoted ? m.quoted: m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const isMedia = /image|video|sticker|audio/.test(mime)

// Variable Prefix 
const prefixRegex = /^[./#!]/; // Prefix
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : ".";
const isCmd = body.startsWith(prefix);
const isPrefixOn = isCmd ? body.slice(1).trim().split(" ").shift().toLowerCase() : ""
const isPrefixOff = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
//const command = isCmd ? body.slice(prefix.length).trim().split(" ").shift().toLowerCase() : '';
const command = setting.prefix ? isPrefixOn : !itsMe && isPrefixOff

// Variable Contributor
let isDev = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(m.sender)) || false;
let contributor = JSON.parse(fs.readFileSync("./main/system/database/moderator.json"))
let isMod = [botNumber, ...contributor].map(v => v.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(m.sender)

// Variable Premium
let premium = JSON.parse(fs.readFileSync("./main/system/database/premium.json"))
let isPremium = [botNumber, ...contributor, ...premium].map(v => v.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(m.sender)
let senderStatus = isDev ? "Dev!" : isMod ? "Mod!" : isPremium ? "Prem!" : "User!"
/*
// Variable Group
let isGroup = m.chat.endsWith("@g.us")
let groupMetadata = m.isGroup ? await vikaru.groupMetadata(m.chat).catch(e => {}): ''
let groupName = m.isGroup && groupMetadata && groupMetadata.subject ? groupMetadata.subject : 'Not Found';
let participants = m.isGroup ? await groupMetadata.participants : ''
let groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
let isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
let isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
let groupOwner = m.isGroup ? groupMetadata.owner : ''
let isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false
*/
// Variable Group
let isGroup = m.chat.endsWith("@g.us");
let groupMetadata = m.isGroup ? await vikaru.groupMetadata(m.chat).catch(e => { return null; }) : null;
let groupName = m.isGroup && groupMetadata && groupMetadata.subject ? groupMetadata.subject : 'Not Found';
let participants = m.isGroup && groupMetadata ? groupMetadata.participants : [];
let groupAdmins = m.isGroup && participants ? await getGroupAdmins(participants) : [];
let isBotAdmins = m.isGroup && groupAdmins.length > 0 ? groupAdmins.includes(botNumber) : false;
let isGroupAdmins = m.isGroup && groupAdmins.length > 0 ? groupAdmins.includes(m.sender) : false;
let groupOwner = m.isGroup && groupMetadata ? groupMetadata.owner : null;
let isGroupOwner = m.isGroup && groupOwner ? (groupOwner ? [groupOwner] : groupAdmins).includes(m.sender) : false;

// Variable Limit
const limitCount = setting.limitCount // Limit
let limit = JSON.parse(fs.readFileSync("./main/system/database/limit.json"));
const { getLimit, isLimit, limitAdd, limitDel, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = require("./system/limit.js");

// Variable Calender
let d = new Date
let gmt = new Date(0).getTime() - new Date("1 Januari 2026").getTime()
let weton = ["Pahing", "Pon","Wage","Kliwon","Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString("id", { weekday: "short" })
let calender = d.toLocaleDateString("id", {
day: "numeric",
month: "long",
year: "numeric"
})
let today = new Date().toLocaleDateString();

// Variable TimeZone
let time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
let wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
let wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z")
let salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a")

// Variable Time Sayings 
let timeSayings
if (time >= "19:00:00" && time < "23:59:00") {
timeSayings = "Good Night"
} else if (time >= "15:00:00" && time < "19:00:00") {
timeSayings = " Good Evening"
} else if (time >= "11:00:00" && time < "15:00:00") {
timeSayings = "Good Afternoon"
} else if (time >= "06:00:00" && time < "11:00:00") {
timeSayings = "Good Morning"
} else {
timeSayings = "Good Nyctophile"
};

//m = Quoted sender ( default )

//qText = Quoted text message
let qText = {
	key: {
		fromMe: false,
		participant: `0@s.whatsapp.net`,
		...(m.chat ? { remoteJid: "status@broadcast" } : {}),
	},
	message: {
		conversation: `👤 *${pushname}*`,
	},
};

//qPayment = Quoted fake payment
let qPayment = {
key: {
remoteJid: "0@s.whatsapp.net",
fromMe: false,
id: "0@s.whatsapp.net",
participant: "0@s.whatsapp.net"
},
message: {
requestPaymentMessage: {
currencyCodeIso4217: "USD", // IDR
amount1000: 99999,
requestFrom: "0@s.whatsapp.net",
noteMessage: {
extendedTextMessage: {
text: `${timeSayings} - ${senderStatus}`,
contextInfo: {
mentionedJid: [`${m.sender}`]}}},
expiryTimestamp: 0,
amount: {
value: 999999999,
offset: 1000,
currencyCode: "USD" }}}}

//qContact = Quoted sender contact
let qContact = {
"key": {
"remoteJid": "status@broadcast",
"fromMe": false,
"id": "0@s.whatsapp.net",
"participants": "0@s.whatsapp.net"
},
"message": {
"contactMessage": {
displayName: pushname+" - "+senderStatus,
"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:;${pushname};;;\nFN:${pushname}\nitem1.TEL;waid=${m.sender.split("@")[0]}:${m.sender.split("@")[0]}\nitem1.X-ABLabel:${pushname}\nEND:VCARD`
}
},
"participant": "0@s.whatsapp.net"
};

/*vikaru.ev.on("messages.update", async (chatUpdate) => {
    for (const { key, update } of chatUpdate) {
        if (update.pollUpdates && key.fromMe) {
            const pollCreation = await getMessage(key);
            if (pollCreation) {
                const pollUpdate = await getAggregateVotesInPollMessage({
                    message: pollCreation,
                    pollUpdates: update.pollUpdates,
                });
                const cmd = pollUpdate.filter((v) => v.voters.length !== 0)[0]?.name;
                if (cmd == undefined) return;
                const command = prefixRegex + cmd;
                console.log(command);

                // Deteksi dan hapus polling
                try {
                await vikaru.sendMessage(key.remoteJid, { delete: { remoteJid: m.chat, id: pollCreation, participant: m.sender } })
                    /*await vikaru.sendMessage(key.remoteJid, {
                        delete: key,
                    });
                    console.log(`Polling dihapus: ${key.id}`);
                } catch (error) {
                    console.error(`Gagal menghapus polling: ${error}`);
                }
            }
        }
    }
});
*/

// Reply Polling message
let sendPoll = (jid, name = '', values = [], selectableCount = '') => {
  return vikaru.sendMessage(jid, {poll: { name, values, selectableCount }});
};

// Reply Message + Forward ( isForwarded: true )
let reply = (jid, teks) => {
vikaru.sendMessage(jid, { text : teks, contextInfo: { forwardingScore: 1000, isForwarded: false }}, { quoted: m })
};

// Reply to commands that are not permitted ( only )
let only = (messnya) => {
vikaru.sendMessage(m.chat, { text: textOnly,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	           forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid,
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: messnya,
                    body: `Status: ${senderStatus}`,
                    thumbnailUrl: "https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg",
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: m })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
};

// Auto Ai
let autoai = JSON.parse(fs.readFileSync("./main/system/database/autoai.json"));
const isAutoai = autoai.includes(m.sender) ? true : false

// Anti Link
let antilink = JSON.parse(fs.readFileSync("./main/system/database/antilink.json"));
const isAntilink = antilink.includes(m.chat) ? true : false
if (isAntilink) {
if (!itsMe && !isDev && !isMod && budy.match(`chat.whatsapp.com`)) {
let gclink = (`https://chat.whatsapp.com/`+await vikaru.groupInviteCode(m.chat))
let isLinkThisGc = new RegExp(gclink, "i")
let isgclink = isLinkThisGc.test(m.text)
if (!isgclink) {
if (isBotAdmins) {
await vikaru.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.key.participant
}
})
} else {
//vikaru.groupParticipantsUpdate(m.chat, [m.sender], "delete")
let user = sender.split("@")[0];
const antilinkMessage =
`You are not allowed to send group links, you must get permission first!

▸ @${user} _\`< m.reply\`_`;
await vikaru.sendMessage(m.chat, { text: antilinkMessage,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [sender], 
	           forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid,
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: `[ ❗ ] - GROUP LINK`,
                    body: "Tap here to get permission...",
                    thumbnailUrl: "https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg",
                    sourceUrl: `https://wa.me/${devNumber}`,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
})
console.log()
console.log(`\x1b[1;32m☰ ANTILINK: \x1b[0mat \x1b[0;32m${calender}\x1b[0m`)
console.log(`\x1b[0m=━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━·>`)
console.log("› Username:", m.pushName ? m.pushName : "Unknown")
console.log("› Captions:", m.text)
console.log()
}
}
}
};

// Anti Culik
if (setting.anticulik) {
if ((m.mtype === "groupInviteMessage" || m.text.startsWith("Undangan untuk bergabung") || m.text.startsWith("Invitation to join") || m.text.startsWith("Buka tautan ini")) && !m.isBaileys && !m.isGroup) {
await vikaru.sendMessage(m.chat, { react: { text: "⚠️", key: m.key }});
await vikaru.sendMessage(m.chat, { text: '',
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	           forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid,
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: "[ ❗ ] - GROUP INVITE",
                    body: `"Tap here to get permission..."`,
                    thumbnailUrl: "https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg",
                    sourceUrl: `https://wa.me/${devNumber}`,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: m })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
    }
};

// Anti-Virtex
if (!itsMe && !isCmd && m.text?.length > 50000) {
await vikaru.sendMessage(m.chat, { react: { text: "⚠️", key: m.key }});
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/spam.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
await vikaru.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
};

// Anti-Toxic
let antitoxic = JSON.parse(fs.readFileSync("./main/system/database/antitoxic.json"));
const isAntitoxic = antitoxic.includes(m.chat) ? true : false
if (isAntitoxic) {
if (!itsMe && budy.match(/pepek|ppk|memek|mmk|kontol|kntl|ngentot|ngentod|ngntd|ngent|tolol|bego|dongo/i)) {
await vikaru.sendMessage(m.chat, { react: { text: "⚠️", key: m.key }});
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/toxic.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}
};

// Silent
let silent = JSON.parse(fs.readFileSync("./main/system/database/silent.json"));
const isSilent = silent.includes(m.chat) ? true : false;
if (isSilent && !itsMe && !isDev && !isMod) {
  if (command || m.text) {
    return false;
  }
}


// Variable setmenu
let setmenu = JSON.parse(fs.readFileSync('./main/settings/setmenu.json'));

// Upload Story
vikaru.uploadStory = async (jids, content) => {
  const fetchParticipants = async (...jids) => {
    const results = await Promise.all(
      jids.map(async (jid) => {
        let { participants } = await vikaru.groupMetadata(jid);
        return participants.map(({ id }) => id);
      })
    );
    return results.flat();
  };

  const msg = await generateWAMessage("status@broadcast", content, {
    upload: vikaru.waUploadToServer,
  });

  let statusJidList = await Promise.all(
    jids.map(async (_jid) =>
      _jid.endsWith("@g.us") ? await fetchParticipants(_jid) : _jid
    )
  );

  statusJidList = [...new Set(statusJidList.flat())];

/*  if (jids.every((jid) => !jid.endsWith("@g.us"))) {
  } else {*/
    await vikaru.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id,
      statusJidList,
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: jids.map((jid) => ({
                tag: "to",
                attrs: { jid },
                content: undefined,
              })),
            },
          ],
        },
      ],
    });

    await Promise.all(
      jids.map((jid) => {
        let type = jid.endsWith("@g.us") ? "groupStatusMentionMessage" : "statusMentionMessage";
        return vikaru.relayMessage(
          jid,
          {
            [type]: {
              message: {
                protocolMessage: {
                  key: msg.key,
                  type: 25,
                },
              },
            },
          },
          {
            additionalNodes: [
              {
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined,
              },
            ],
          }
        );
      })
    );
  //}

  return msg;
};

// Variable image( case menu )
let imgFile = await fs.readFileSync("./main/media/image/menu.jpg")
const imgUrl = "https://telegra.ph/file/4a18ce660b79afea0058a.jpg"
let imgUrlRandom = await axios.get(`https://api.waifu.pics/sfw/waifu`).then(({data}) => data.url )
let ppUrl = await vikaru.profilePictureUrl(m.sender, "image").catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg")

// Exports Text
let { textMenu } = require("./system/exports/menu.js")
let { textGroup } = require("./system/exports/group.js")
let { textOnly } = require("./system/exports/only.js")
let { textVoice } = require("./system/exports/voice.js")
let { textSfw } = require("./system/exports/sfw.js")
let { textNsfw } = require("./system/exports/nsfw.js")
let { textClear } = require("./system/exports/clear.js")
let { textVirtex } = require("./system/exports/virtex.js")

// Read incoming command messages
let read = async (emote) => {
    // Auto read
    if (setting.autoread) {
      await vikaru.readMessages([m.key]);
    }
    
    // Typing
    if (setting.typing) {
      await vikaru.sendPresenceUpdate("composing", m.chat);
    }

    // Reaction
    await vikaru.sendMessage(m.chat, { react: { text: emote, key: m.key }});
};

// Check limit
if (command && !isDev && !isMod && !isPremium && isLimit(m.sender, limitCount, limit)) {
return reply(sender, "> ⓘ Usage limit has been reached");
}

// List Command ( Cannot be deleted ) ( default )
switch (command) {


//------------------------------------------------------------------------------------//



/* Need questions ?
 - WhatsApp : https://wa.me/6289508899033
 - Telegram  : https://t.me/dcodemaxz 
 */



//━━━━━━━━━━━[ OTHER MENU ]━━━━━━━━━━━━//

case "tes": {
await sendPoll(m.chat, 'Title', ['ping', 'owner'], 1);
} break;

case 'tes2': {

                if (args[0].toLowerCase() === 'close'){
                    m.reply('hy')
                } else if (args[0].toLowerCase() === 'open'){
                    m.reply('hyy')
                } else {
                    sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} Open`,`${command.charAt(0).toUpperCase()+command.slice(1)} Close`])
             }
            }
            break
            
// All Menu
case "list":
case "listmenu":
case "menulist":
case "menu":
case "allmenu":
case "menuall": {
await read("🧬");

// "textMenu" Exports from ("./system/exports/menu.js")
const textnya = `${textMenu}`

/*async function loading () {
var load = [
"> 《 [▒▒▒▒▒▒▒▒▒▒▒▒] 》0%",
"> 《 [█▒▒▒▒▒▒▒▒▒▒▒] 》10%",
"> 《 [████▒▒▒▒▒▒▒▒] 》30%",
"> 《 [███████▒▒▒▒▒] 》50%",
"> 《 [██████████▒▒] 》80%",
"> 《 [████████████] 》100%",
"> ⓘ `loading-complete!`"
]
const { key } = await vikaru.sendMessage(m.chat, {text: "> ⓘ `loading-command...`"}, { quoted: m })

for (let i = 0; i < load.length; i++) {
await vikaru.sendMessage(m.chat, {text: load[i], edit: key })
}
loading();
*/

// Menu 1
if (setmenu.menu1) {
await vikaru.sendMessage(m.chat, {
    document: fs.readFileSync("./main/media/document/menu.txt"),
    fileName: `${pushname} - ${senderStatus}`,
    mimetype: 'image/png',
    jpegThumbnail: await resize(ppUrl, 400, 400),
    contextInfo: {
        mentionedJid: [m.sender], 
        isForwarded: true,
        externalAdReply: {
        title: `${botName} • ${version}`,
        body: `Limit: ${isDev ? "∞" : isMod ? "∞" : isPremium ? "∞" : getLimit(m.sender, limitCount, limit)}`, 
         thumbnail: fs.readFileSync("./main/media/image/menu.jpg"),
        sourceUrl: global.sosmed,
       mediaType: 1,
        renderLargerThumbnail: true
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: global.newsletter.jid,
            serverMessageId: null,
            newsletterName: global.newsletter.name
        },
    },
  caption: textnya,
  footer: footer,
  headerType: 1,
  viewOnce: true
}, { quoted: qPayment })

// Voice chat menu
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync(`./main/media/audio/menu1.mp3`), mimetype: "audio/mp4", ptt: true });
}

// Menu 2
else if (setmenu.menu2) {
await vikaru.sendMessage(m.chat, {document: fs.readFileSync("./main/media/document/menu.txt"), mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", caption: textnya, fileName: `${timeSayings} - ${isDev ? "Dev!" : isPremium ? "Prem!" : "User!"}`,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid,
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: `${botName} • ${global.version}`,
                    body: `Limit: ${isDev ? "∞" : isMod ? "∞" : isPremium ? "∞" : getLimit(m.sender, limitCount, limit)}`,
                    thumbnail: imgFile, // Profile image
                    //thumbnailUrl: imgUrlRandom,
                    //thumbnailUrl: ppUrl, // sender profile image
                    sourceUrl: `${global.sosmed}`,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
}, { userJid: m.chat, quoted: qContact })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
 
// Voice chat menu
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync(`./main/media/audio/menu2.mp3`), mimetype: "audio/mp4", ptt: true });
}

// Menu 3
else if (setmenu.menu3) {
await vikaru.sendMessage(m.chat, { text: textnya,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid, // 6289508899033@s.whatsapp.net
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: `${botName} • ${global.version}`,
                    body: author,
                    thumbnail: imgFile,
                    sourceUrl: `${global.sosmed}`,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: qContact })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })

// Meu 4
} else if (setmenu.menu4) {
await vikaru.sendMessage(m.chat, {
poll: {
name: "Maintenance!",
values: ["ping", "owner"],
selectableCount: 1 // 2 : More than 1 choice
}
}, { quoted: m })

// Menu 5
} else if (setmenu.menu5) {
const uploadFile = { upload: vikaru.waUploadToServer };
        var imageMessage = await prepareWAMessageMedia(
          {
            image: imgFile,
          },
          uploadFile,
        );
        const product = {
          productImage: imageMessage.imageMessage,
          productId: "7066960336725723",
          title: `${botName} • ${global.version}`,
          description: textMenu,
          currencyCode: "IDR",
          priceAmount1000: "25000000",
          productImageCount: 1,
        };
        const productData = {
          product: product,
          businessOwnerJid: "6289508899033@s.whatsapp.net",
        };
        const productMessage = { productMessage: productData };
        var response = await generateWAMessageFromContent(
          m.chat,
          proto.Message.fromObject(productMessage),
          m.quoted && m.quoted.fromMe
            ? { contextInfo: { ...m.msg.contextInfo } }
            : { quoted: m },
        );
        await vikaru.relayMessage(m.chat, response.message, {
          messageId: response.key.id,
        });
}
} break;


// Say <text>
case "say": {
await read("☑️");
reply(m.chat, text)
} break;


// Ping
case "ping": {
  await read("🏓");
  const start = Date.now();
  const pongMessage = await vikaru.sendMessage(m.chat, { text: "Speed Test!" }, { quoted: m });
  const end = Date.now();
  const ping = end - start;
  await vikaru.sendMessage(m.chat, {
    text: `Response speed: ${ping}ms`,
    edit: pongMessage.key,
  });
} break;



// Shop Menu
case "sewabot":
case "daftarprem":
case "buyprem":
case "price":
case "sewa":
case "shop":
case "store": {
  await read("🛍️");
  const uploadFile = { upload: vikaru.waUploadToServer };
  const products = [
    {
      name: "Starter 1",
      price: "Rp 5.000 ( ~Rp 6.000~ )",
      description: "> 1 Minggu Masuk Grup\n> 1 Minggu Premium",
      image: "./main/media/image/basic1.jpg",
      buttonText: "🛍️ Buy ( Starter 1 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Starter+1`,
    },
    {
      name: "Starter 2",
      price: "Rp 3.000",
      description: "> 1 Minggu Masuk Grup",
      image: "./main/media/image/basic2.jpg",
      buttonText: "🛍️ Buy ( Starter 2 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Starter+2`,
    },
    {
      name: "Starter 3",
      price: "Rp 3.000",
      description: "> 1 Minggu Premium",
      image: "./main/media/image/basic3.jpg",
      buttonText: "🛍️ Buy ( Starter 3 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Starter+3`,
    },
    {
      name: "Scale 1",
      price: "Rp 12.000 ( ~Rp 15.000~ )",
      description: "> 1 Bulan Masuk Grup\n> 1 Bulan Premium",
      image: "./main/media/image/silver1.jpg",
      buttonText: "🛒 Buy ( Scale 1 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Scale+1`,
    },
    {
      name: "Scale 2",
      price: "Rp 10.000",
      description: "> 1 Bulan Masuk Grup",
      image: "./main/media/image/silver2.jpg",
      buttonText: "🛒 Buy ( Scale 2 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Scale+2`,
    },
    {
      name: "Scale 3",
      price: "Rp 5.000",
      description: "> 1 Bulan Premium",
      image: "./main/media/image/silver3.jpg",
      buttonText: "🛒 Buy ( Scale 3 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Scale+3`,
    },
    {
      name: "Enterprise 1",
      price: "Rp 30.000",
      description: "> 1 Bulan Murid Bot\n> Sc Base-Vikaru-Md\n> Pairing Code\n> Access free updates",
      image: "./main/media/image/gold1.jpg",
      buttonText: "💳 Buy ( Enterprise 1 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Enterprise+1`,
    },
    {
      name: "Enterprise 2",
      price: "Rp 25.000",
      description: "> Sc Base-Vikaru-Md\n> Pairing Code\n> Access free updates",
      image: "./main/media/image/gold2.jpg",
      buttonText: "💳 Buy ( Enterprise 2 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Enterprise+2`,
    },
    {
      name: "Enterprise 3",
      price: "Rp 30.000",
      description: "> Sc Vikaru-Bot\n> Pairing Code\n> Sc Autoresponder\n> Sc Tasker\n> Access free updates",
      image: "./main/media/image/gold3.jpg",
      buttonText: "💳 Buy ( Enterprise 3 )",
      buttonUrl: `https://api.whatsapp.com/send/?phone=${devNumber.split("@")[0]}&text=Min+Beli+Bot+Enterprise+3`,
    },
  ];

  const cards = await Promise.all(products.map(async (product) => {
    const imageMedia = await prepareWAMessageMedia({ image: fs.readFileSync(product.image) }, uploadFile);
    return {
      body: proto.Message.InteractiveMessage.Body.create({ text: `*• ${product.name}* : ${product.price}\n${product.description}` }),
      footer: proto.Message.InteractiveMessage.Footer.create({ text: global.footer }),
      header: proto.Message.InteractiveMessage.Header.create({
        title: `*${product.name.split(" ")[0].toUpperCase()} PLAN*`,
        subtitle: "Evolution 🧬",
        imageMessage: imageMedia.imageMessage,
        hasMediaAttachment: true,
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
        buttons: [{
          name: "cta_url",
          buttonParamsJson: `{"display_text":"${product.buttonText}","url":"${product.buttonUrl}","merchant_url":"${product.buttonUrl}"}`,
        }],
      }),
    };
  }));

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({ text: "Store menu list..." }),
          footer: proto.Message.InteractiveMessage.Footer.create({ text: global.author }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "*Select Product ▸*",
            subtitle: "Evolution 🧬",
            hasMediaAttachment: false,
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({ cards }),
        }),
      },
    },
  }, { quoted: m });

  await vikaru.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
} break;


// Contact Developer 
case "contact":
case "owner":
case "ownerbot":
case "botowner": {
await read("👑");
/*const ownContact = {
displayName: "Contact", contacts: [{displayName: devName, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+devName+";;;\nFN:"+devName+"\nitem1.TEL;waid="+global.devNumber+":"+global.devNumber+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
};*/
const ownContact = {
displayName: "Display Name", contacts: [{displayName: "Contact Name", vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${devName}\nORG:© Developer\nitem1.TEL;waid=${devNumber}:${devNumber}\nitem1.X-ABLabel: Jangan lupa di save!\nEMAIL;TYPE=Jangan di hack:dcodemaxz@gmail.com\nURL:https://linktr.ee/dcodemaxz\nEND:VCARD`}]
};
const soContact = await vikaru.sendMessage(m.chat, {contacts: ownContact}, {quoted: m })
// Timeout
setTimeout(() => {vikaru.sendMessage(m.chat, {delete: soContact.key})}, 20000)
} break;


// Uptime
case "uptime":
case "runtime": {
await read("☑️");
await reply(m.chat, runtime(process.uptime()))
} break;


//━━━━━━━━━━━[ AI MENU ]━━━━━━━━━━━━//

// Ai / Gemini
case "ai":
case "gemini": {
await read("🔎");
  try {
    if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <query>`);

    const { data } = await axios.get(`https://sandipbaruwal.onrender.com/gemini?prompt=${encodeURIComponent(`&Prompt:Balas pesan berikut sesuai dengan bahasa dan kosa kata yang digunakan lawan bicara kamu (“${pushname}"), dan sajikan informasi serapih dan semenarik mungkin&text:` + text)}`);

    if (data.status === "error") {
      reply(m.chat, `Server sedang down!`);
    } else {
      reply(m.chat, data.answer);
    }
  } catch (error) {
    console.log(error);
    reply(m.chat, "Status error");
  }
} break;


// Ai simsimi
case "simi": {
await read("☑️");
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <text>`)
let {data} = await axios.get(`https://sandipbaruwal.onrender.com/sim?chat=${encodeURIComponent(text)}&lang=id`); 
reply(m.chat, data.answer);
} break;


// Auto ai on/off
case "autoai": {
await read("⛩️");
if (args[0] === "on") {
if (isAutoai) return reply(m.chat, "Already active")
autoai.push(m.sender)
fs.writeFileSync("./main/system/database/autoai.json", JSON.stringify(autoai, null, 2));
reply(m.chat, mess.done)
} else if (args[0] == "off") {
if (!isAutoai) return reply(m.chat, "Already inactive")
let anu = autoai.indexOf(m.sender)
autoai.splice(anu, 1)
fs.writeFileSync("./main/system/database/autoai.json", JSON.stringify(autoai, null, 2))
reply(m.chat, mess.done)
} else {
reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
}
} break;


// Image Generator
case "ilustrasi": {
await read("☑️");
await vikaru.sendMessage(m.chat, { react: { text: "☑️", key: m.key } });
if (!args[0]) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <text>`)
await reply(m.chat, mess.wait)
let data = await getBuffer(`https://api.siputzx.my.id/api/ai/stabilityai?prompt=${encodeURIComponent(text)}`)
await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: mess.done}, { quoted: m });
} break;


// Image Ilustrasi
case "generate": {
await read("☑️");
await vikaru.sendMessage(m.chat, { react: { text: "☑️", key: m.key } });
if (!args[0]) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <text>`)
await reply(m.chat, mess.wait)
let data = await getBuffer(`https://api.siputzx.my.id/api/ai/stable-diffusion?prompt=${encodeURIComponent(text)}`)
await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: mess.done}, { quoted: m });
} break;


// Nsfw generator
case "imgnsfw": {
await read("☑️");
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <text>`)
await reply(m.chat, mess.wait)
let {data} = await axios.get(`https://sandipbaruwal.onrender.com/pussy?prompt=${text}`); 
await vikaru.sendMessage(m.chat, { image: {url: data.url}, mimetype: "image/jpeg", caption: mess.done, viewOnce: true }, { quoted: m });
} break;


//━━━━━━━━━━━[ CONVERT MENU ]━━━━━━━━━━━━//


// Sticker
case "sticker":
case "stiker":
case "s": {
await read("☑️");
  if ((!m.quoted && !isMedia) || (!isMedia)) {
    return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image/Video/GIF>");
  }

  let media;
  if (m.quoted) {
    media = await quoted.download();
  } else {
    media = await vikaru.downloadMediaMessage(m.message.imageMessage);
  }

  try {
    if (/image/.test(mime) || m.message.imageMessage) {
      await vikaru.sendImageAsSticker(m.chat, media, m, {
        packname: global.packname,
        author: global.author
      });
    } else if (/video/.test(mime)) {
      if ((quoted.msg || quoted).seconds > 11) return reply(m.chat, "Maximum duration 10 seconds!");
      await vikaru.sendVideoAsSticker(m.chat, media, m, {
        packname: global.packname,
        author: global.author
      });
    } else if (/gif/.test(mime)) {
      await vikaru.sendImageAsSticker(m.chat, media, m, {
        packname: global.packname,
        author: global.author
      });
    } else {
      return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image/Video/GIF>");
    }
  } catch (error) {
    console.log(error);
    reply(m.chat, "Not supported by this media!");
  } finally {
    //await fs.unlinkSync(media);
  }
} break;

// Brat Image
case "brat":
case "bratimg": {
  await read("☑️");
  if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);
  try {
    reply(m.chat, mess.wait);
    const media = await getBuffer(`https://kenshinaru-api.hf.space/brat?text=${encodeURIComponent(text)}`);
    await vikaru.sendImageAsSticker(m.chat, media, m, {
      packname: global.packname,
      author: global.author
    });
  } catch (error) {
    console.error("Error brat1:", error);
    reply(m.chat, mess.err);
  }
} break;


// Brat Video
case "bratvid": {
  await read("☑️");
  if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);
  try {
    reply(m.chat, mess.wait);
    const media = await getBuffer(`https://kenshinaru-api.hf.space/brat-vid?text=${encodeURIComponent(text)}`);
    await vikaru.sendVideoAsSticker(m.chat, media, m, {
      packname: global.packname,
      author: global.author
    });
  } catch (error) {
    console.error("Error brat2:", error);
    reply(m.chat, mess.err);
  }
} break;


// Spotify download
case "spotifyd": {
  await read("📥");
  if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <link>`);
    
    await fetch(`https://api.siputzx.my.id/api/d/spotify?url=${text}`).then(async (res) => {
        const response = await res.json();
        
        if (response.status) {
            const album = response.data;
            const title = album.title;
            const artist = album.artis;
            const duration = album.durasi; 
            const image = album.image;
            const downloadLink = album.download;

            const minutes = Math.floor(duration / 60);
            const seconds = duration % 60;

            const formattedSeconds = seconds < 10 ? `0${seconds}` : seconds;

            let message = `*-Album:* ${title}\n*Artis:* ${artist}\n*Durasi:* ${minutes} menit ${formattedSeconds} detik\n*Download:* ${downloadLink}`;
            
            await vikaru.sendMessage(
            m.chat, {
                audio: {
                    url: downloadLink
                },
                mimetype: "audio/mpeg",
                fileName: `${title}.mp3`,
                contextInfo: {
                    externalAdReply: {
                        mediaType: 1,
                        title: `${title} - ${artist}`,
                        body: global.author,
                        thumbnailUrl: image,
                        renderLargerThumbnail: true
                    }
                }
            }, {
                quoted: m
            }
        );
        } else {
            reply(m.chat, 'Album not found or an error occurred!');
        }
    }).catch(err => reply(mess.err));
} break;


// Tiktok mp4
case "tt":
case "ttmp4":
case "tiktok": {
  await read("☑️");
  await vikaru.sendMessage(m.chat, { react: { text: "📥", key: m.key } });
  if (!text || !isUrl(text)) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <link>`);

  try {
    await reply(m.chat, mess.wait)
    let data = await getBuffer(`https://sandipbaruwal.onrender.com/tikdown?url=${text}`);

    if (!data) { // Check if getBuffer returned null or undefined
      console.log("getBuffer returned null or undefined for TikTok");
      return reply(m.chat, "Tidak ada data yang dihasilkan.");
    }
    await vikaru.sendMessage(m.chat, { video: data, caption: mess.done }, { quoted: m });
  } catch (error) {
    console.log("Error downloading TikTok video:", error);

    if (error.response && error.response.status === 500) {
      reply(m.chat, "Server sedang mengalami gangguan. Coba lagi nanti.");
    } else if (error.message.includes("HTTPError: Request failed with status code 404")) {
        reply(m.chat, "Video TikTok tidak ditemukan atau bersifat pribadi.");
    } else {
      reply(m.chat, "The link you provided is invalid.");
    }
  }
} break;

// Tiktok mp3
case "ttmp3": {
    await read("📥");
    if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <link>`);

    if (!(text.includes('http://') || text.includes('https://'))) return reply(`URL tidak valid, silakan masukkan URL yang valid.`);
    if (!text.includes('tiktok.com')) return reply(m.chat, "TikTok URL is invalid!");

    try {
        await reply(m.chat, mess.wait);
        const response = await fetch(`https://api.riicode.my.id/api/download/tiktokdl?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (!data.status) {
            return reply(m.chat, "Failed to fetch data from TikTok.");
        }

        const result = data.result;
        const videoUrl = result.video_nowm; 
        const audioUrl = result.audio_url;
        const description = result.description; 

        await vikaru.sendMessage(m.chat, {
            video: await fetchBuffer(videoUrl),
            caption: `📹 *${description}*`
        }, {
            quoted: m
        });

        await vikaru.sendMessage(m.chat, {
            audio: await fetchBuffer(audioUrl),
            mimetype: 'audio/mpeg'
        }, {
            quoted: m
        });

    } catch (e) {
        console.error(e);
        await reply(m.chat, mess.err);
    }
}
break;


// Facebook Downloader
case "fb":
case "facebook": {
  await read("☑️");
  await vikaru.sendMessage(m.chat, { react: { text: "📥", key: m.key } });
  if (!text || !isUrl(text)) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <link>`);

  try {
    await reply(m.chat, mess.wait)
    let data = await getBuffer(`https://sandipbaruwal.onrender.com/download2?url=${text}`);

    if (!data) { // Check if getBuffer returned null or undefined
      console.log("getBuffer returned null or undefined for TikTok");
      return reply(m.chat, "Tidak ada data yang dihasilkan.");
    }
    await vikaru.sendMessage(m.chat, { video: data, caption: mess.done }, { quoted: m });
  } catch (error) {
    console.log("Error downloading Facebook video:", error);

    if (error.response && error.response.status === 500) {
      reply(m.chat, "Server sedang mengalami gangguan. Coba lagi nanti.");
    } else if (error.message.includes("HTTPError: Request failed with status code 404")) {
        reply(m.chat, "Video Facebook tidak ditemukan atau bersifat pribadi.");
    } else {
      reply(m.chat, "The link you provided is invalid.");
    }
  }
} break;


// Instagram Downloader
case "ig":
case "instagram": {
  await read("☑️");
  await vikaru.sendMessage(m.chat, { react: { text: "📥", key: m.key } });
  if (!text || !isUrl(text)) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <link>`);

  try {
    await reply(m.chat, mess.wait)
    let data = await getBuffer(`https://sandipbaruwal.onrender.com/instadown?url=${text}`);

    if (!data) { // Check if getBuffer returned null or undefined
      console.log("getBuffer returned null or undefined for Instagram");
      return reply(m.chat, "Tidak ada data yang dihasilkan.");
    }
    await vikaru.sendMessage(m.chat, { video: data, caption: mess.done }, { quoted: m });
  } catch (error) {
    console.log("Error downloading Instagram video:", error);

    if (error.response && error.response.status === 500) {
      reply(m.chat, "Server sedang mengalami gangguan. Coba lagi nanti.");
    } else if (error.message.includes("HTTPError: Request failed with status code 404")) {
        reply(m.chat, "Postingan Instagram tidak ditemukan atau bersifat pribadi.");
    } else {
      reply(m.chat, "The link you provided is invalid.");
    }
  }
} break;


//━━━━━━━━━━━[ SEARCH MENU ]━━━━━━━━━━━━//


// News
case "news":
case "berita": {
await read("🗞️");
  try {
    const response = await axios.get(`https://api.siputzx.my.id/api/berita/antara`);

    if (response.data && response.data.data && Array.isArray(response.data.data) && response.data.data.length > 0) {
      const dataBerita = response.data.data;
      const randomIndex = Math.floor(Math.random() * dataBerita.length);
      const berita = dataBerita[randomIndex];
      const { image, title, link, category } = berita;

      await vikaru.sendMessage(m.chat, {
        text: `Random Berita 📰\n${link}`,
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender],
          forwardedNewsletterMessageInfo: {
            newsletterJid: global.newsletter.jid,
            newsletterName: global.newsletter.name,
            serverMessageId: -1
          },
          externalAdReply: {
            title: title,
            body: category,
            thumbnailUrl: image,
            sourceUrl: link,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { userJid: m.chat, quoted: m });

      vikaru.relayMessage(m.key.remoteJid, m.chat, { messageId: m.key.id });

    } else {
      console.log("Data berita tidak valid atau kosong:", response.data);
      await reply(m.chat, "Tidak ada berita ditemukan.")
    }

  } catch (error) {
    console.log("Error fetching news:", error);
    await reply(m.chat, "Gagal mengambil berita.")
  }
} break;


// Random Sounds
case "sound": {
await read("☑️");
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <number>`);
if (/^\d+$/.test(text)) {
    if (text > 161) {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* 1-161`);
    } else {
        let link = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command+text}.mp3`;
        try {
        await vikaru.sendMessage(m.chat, { audio: { url: link }, mimetype: "audio/mpeg" }, { quoted: m });
        } catch (error) {
        console.log("Error fetching audio:", error);
        return reply(m.chat, mess.err);
        }
    }
} else {
    return reply(m.chat, "Input must be numbers only!");
}
} break;


// Spotify search
case "spotifys":
case "spotify": {
  await read("☑️");
    if (!text) return m.reply(`> ⓘ Ex: *${prefix+command}* <query>`);

    try {
        await reply(m.chat, mess.wait)
        const response = await axios.get(`https://sandipbaruwal.onrender.com/spotify?query=${encodeURIComponent(text)}`);
        const results = response.data;

        if (!results || results.length === 0) return m.reply("> ⓘ No results found for that search!");

        let cards = [];

        for (let i = 0; i < results.length; i++) {
            let { name, artist, release_date, duration, link, image_url } = results[i];

            cards.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `- 🎵 *Title:* ${name}\n- 👤 *Artist:* ${artist}\n- 📅 *Release:* ${release_date}\n- 🕒 *Duration:* ${duration}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: footer
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Results ${i + 1}`,
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({ image: { url: image_url } }, { upload: vikaru.waUploadToServer }))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Periview","url":"${link}"}`
                        },
                        {
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Download","copy_code":"/spotifyd ${link}"}`
                        }
                    ]
                })
            });
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.newsletter.jid,
                                newsletterName: global.newsletter.name,
                                serverMessageId: -1
                            },
                            businessMessageForwardInfo: { businessOwnerJid: vikaru.decodeJid(vikaru.user.id) },
                            forwardingScore: 256,
                            externalAdReply: {
                                title: "Spotify Search",
                                thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/1/19/Spotify_logo_without_text.svg",
                                sourceUrl: "https://www.spotify.com",
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `🔎 *Keyword:* ${text}`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: author
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });

        vikaru.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    } catch (error) {
        console.error(error);
        m.reply("> ⓘ Error! Coba lagi nanti.");
    }
} break;


// Pinterest
case "pin":
case "pinterest": {
    await read("🔎");
    if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <query>`);

    try {
        await reply(m.chat, mess.wait)
        const response = await axios.get(`https://api.diioffc.web.id/api/search/pinterest?query=${encodeURIComponent(text)}`);
        const results = response.data.result;

        if (!results.length) return m.reply("> ⓘ No results found for that search!");

        let cards = [];

       //for (let i = 0; i < Math.min(results.length, 5); i++) {
       for (let i = 0; i < results.length; i++) { // Ambil semua hasil dari API
    let { src, title, link } = results[i];

    cards.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
            text: title || "Description not found!."
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: footer
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Result ${i + 1}`,
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ image: { url: src } }, { upload: vikaru.waUploadToServer }))
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"Periview","url":"${link}"}`
                }
            ]
        })
    });
}

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.newsletter.jid,
                                newsletterName: global.newsletter.name,
                                serverMessageId: -1
                            },
                            businessMessageForwardInfo: { businessOwnerJid: vikaru.decodeJid(vikaru.user.id) },
                            forwardingScore: 256,
                            externalAdReply: {
                                title: "Pinterest Search",
                                thumbnailUrl: "https://i.pinimg.com/originals/4a/9f/58/4a9f58bf78d3b332d82dad1bc9d229ae.jpg",
                                sourceUrl: "https://www.pinterest.com",
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `🔎 *Keyword:* ${text}`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: author
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });

        vikaru.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error(error);
        m.reply(mess.err);
    }
} break;


// YouTube Search
case "ytsearch":
case "yts": {
await read("🔎");
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <query>`);

    try {
        await reply(m.chat, mess.wait)
        const response = await axios.get(`https://api.diioffc.web.id/api/search/youtube?query=${encodeURIComponent(text)}`);
        const results = response.data.result;

        if (!results.length) return m.reply("> ⓘ No results found for that search!");

        let cards = [];

        for (let i = 0; i < results.length; i++) {
            let { title, description, url, thumbnail, author, views, duration, ago } = results[i];
            let authorName = author && author.name ? author.name : "Private";
            let videoViews = views ? parseInt(views).toLocaleString() : "Tidak Ada";
            let videoDuration = duration?.timestamp || "Tidak Ada";
            
            cards.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `- 📌 *Judul:* ${title}\n- 👤 *Author:* ${authorName}\n- ⏳ *Durasi:* ${videoDuration}\n- 👀 *Views:* ${videoViews}\n- 📆 *Upload:* ${ago}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: footer
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Results ${i + 1}`,
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({ image: { url: thumbnail } }, { upload: vikaru.waUploadToServer }))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Periview","url":"${url}"}`
                        },
                        {
                            name: "cta_copy",
                            buttonParamsJson: `{\"display_text\":\"Copy Url\",\"copy_code\":\"${url}\"}`
                        }
                    ]
                })
            });
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.newsletter.jid,
                                newsletterName: global.newsletter.name,
                                serverMessageId: -1
                            },
                            businessMessageForwardInfo: { businessOwnerJid: vikaru.decodeJid(vikaru.user.id) },
                            forwardingScore: 256,
                            externalAdReply: {
                                title: "YouTube Search",
                                thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/b/b8/YouTube_Logo_2017.svg",
                                sourceUrl: "https://www.youtube.com",
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `🔎 *Keyword:* ${text}`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: author
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });

        vikaru.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.error(error);
        m.reply(mess.err);
    }
} break


//━━━━━━━━━━━[ ANIME MENU ]━━━━━━━━━━━━//


// Random Waifu
case "sfw":
case "nsfw": {
  await read("⛩️");
  if (!text) {
    if (command === "sfw") {
      var teksnya = textSfw;
    } else if (command === "nsfw") {
      var teksnya = textNsfw;
    } else {
      reply(m.chat, "Command salah!");
      return;
    }

    await vikaru.sendMessage(
      m.chat,
      {
        text: teksnya,
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender],
          forwardedNewsletterMessageInfo: {
            newsletterJid: global.newsletter.jid,
            newsletterName: global.newsletter.name,
            serverMessageId: -1,
          },
          externalAdReply: {
            title: "[ ⛩️ ] - RANDOM ANIME",
            body: "",
            thumbnailUrl: imgUrlRandom,
            sourceUrl: `${global.sosmed}`,
            mediaType: 1,
            renderLargerThumbnail: false,
          },
        },
      },
      { userJid: m.chat, quoted: m }
    );
    vikaru.relayMessage(m.key.remoteJid, m.chat, {
      messageId: m.key.id,
    });
  } else {
    try {
      await reply(m.chat, mess.wait)
      let data = await axios.get(`https://api.waifu.pics/${command}/${text}`).then(({ data }) => data.url);

      if (data) {
        await vikaru.sendMessage(m.chat, { image: { url: data }, mimetype: "image/jpeg", caption: "Random Anime ✨", viewOnce: true }, { quoted: m });
      } else {
        reply(m.chat, "Image not found.");
      }
      //if (isGroup) return reply(m.chat, mess.done);
    } catch (error) {
      console.log("Error fetching waifu:", error);
      reply(m.chat, "the input you entered is incorrect.");
    }
  }
} break;


// Randome Anime
case "anime": 
case "randomanime": {
await read("😋");
try {
await reply(m.chat, mess.wait)
let data = await getBuffer("https://archive-ui.tanakadomp.biz.id/asupan/anime")
await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: "Random Anime ✨", viewOnce: true }, { quoted: m });
 } catch (err) {
   console.log(err)
   reply(m.chat, err)
  }
 } break;


// Voice chat
case "voice": {
await read("☑️");
await vikaru.sendMessage(m.chat, { text: textVoice,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid, // 6289508899033@s.whatsapp.net
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: "[ 🔊 ] - VOICE CHAT",
                    body: "List sound vn",
                    thumbnailUrl: imgUrl,
                    //thumbnailUrl: imgUrlRandom,
                    //thumbnail: imgFile,
                    //thumbnailUrl: ppUrl,
                    //sourceUrl: `https://wa.me/6289513484928`,
                    sourceUrl: `${global.sosmed}`,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: m })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
} break;


// Random Cecan
case "cecan": {
await read("🌹");
const teksnya =
` ☰  *\`ʀᴀɴᴅᴏᴍ ᴄᴇᴄᴀɴ\`*
∘╌────────────────╌∘
  ▸ /cecan Indonesia
  ▸ /cecan china
  ▸ /cecan japan
  ▸ /cecan korea
  ▸ /cecan thailand
  ▸ /cecan vietnam

${global.footer}`

  if (!text) {
    await reply(m.chat, mess.wait)
    await vikaru.sendMessage(
      m.chat,
      {
        text: teksnya,
        contextInfo: {
          isForwarded: true,
          mentionedJid: [m.sender],
          forwardedNewsletterMessageInfo: {
            newsletterJid: global.newsletter.jid,
            newsletterName: global.newsletter.name,
            serverMessageId: -1,
          },
          externalAdReply: {
            title: "[ 🌹 ] - RANDOM CECAN",
            body: "",
            thumbnailUrl: imgUrl,
            sourceUrl: `${global.sosmed}`,
            mediaType: 1,
            renderLargerThumbnail: false,
          },
        },
      },
      { userJid: m.chat, quoted: m }
    );
    vikaru.relayMessage(m.key.remoteJid, m.chat, {
      messageId: m.key.id,
    });
  } else {
    try {
      let data = await getBuffer(`https://api.siputzx.my.id/api/r/cecan/${text}`)

      if (data) {
        await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: "Random Cecan ✨", viewOnce: true }, { quoted: m });
      } else {
        reply(m.chat, "Image not found.");
      }
      //if (isGroup) return reply(m.chat, mess.done);
    } catch (error) {
      console.log("Error fetching waifu:", error);
      reply(m.chat, "the input you entered is incorrect.");
    }
  }
} break;


// Randome Cosplay
case "cosplay": 
case "randomcosplay": {
await read("💅🏻");
try {
await reply(m.chat, mess.wait)
let data = await getBuffer("https://archive-ui.tanakadomp.biz.id/asupan/cosplay")
await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: "Random Cosplay ✨", viewOnce: true }, { quoted: m });
 } catch (err) {
   console.log(err)
   reply(m.chat, err)
  }
 } break;


//━━━━━━━━━━━[ TOOLS MENU ]━━━━━━━━━━━━//


case "es": {
const messa = await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8089ac60dd17836dcd0bf.jpg' } }, { upload: vikaru.waUploadToServer })
const catalog = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"productMessage": {
"product": {
"productImage": messa.ppUrl, 
"productId": "5489299044451325",
"title": `QRIS - SATU UNTUK SEMUA`,
"description": `Tnx for donation`,
"currencyCode": "IDR",
"bodyText": 'Hai',
"footerText": 'Max',
"priceAmount1000": "5000",
"productImageCount": 1,
"firstImageId": 1,
"salePriceAmount1000": "10000000",
"retailerId": author,
"url": "http://wa.me/6289508899033"
},
"businessOwnerJid": "6289508899033@s.whatsapp.net",
}
}), { userJid: m.chat, quoted: m })
} break
// Remini
case "hd": {
  await read("☑️");
  if ((!m.quoted && !isMedia) || (!isMedia)) {
    return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image/GIF>");
  }

  let media;
  if (m.quoted) {
    media = await quoted.download();
  } else {
    media = await vikaru.downloadMediaMessage(m.message.imageMessage);
  }

  try {
    await reply(m.chat, mess.wait)
    let data = await remini(media, "enhance")
      if (/image/.test(mime) || m.message.imageMessage) {
        await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: mess.done }, { quoted: m });
      } else if (/gif/.test(mime)) {
        await vikaru.sendMessage(m.chat, { image: data, mimetype: "image/jpeg", caption: mess.done }, { quoted: m });
      } else {
        return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image/GIF>");
      }
  } catch (error) {
    console.error(error);
    reply(m.chat, "Error saat memproses media.");
  } finally {
    //await fs.unlinkSync(media);
  }
} break;


// Read view once
case "rvo":
case "read":
case "readviewonce": {
await read("☑️");
if (!isDev && !isMod) return await only(mess.mod);
if (!m.quoted) return reply(m.chat, "> ⓘ Ex: *Reply* <Image/Video/Audio>");

    try {
        let mediaType = quoted.mimetype;
        let media = await quoted.download(); 
        let caption = quoted.caption || ""; 

        if (mediaType.startsWith("image/")) {
            await vikaru.sendMessage(m.chat, {
                image: media,
                caption: caption,
                mimetype: mediaType
            }, { quoted: m });
        } else if (mediaType.startsWith("video/")) {
            await vikaru.sendMessage(m.chat, {
                video: media,
                caption: caption,
                mimetype: mediaType
            }, { quoted: m });
        } else if (mediaType.startsWith("audio/")) {
            await vikaru.sendMessage(m.chat, {
                audio: media,
                caption: caption,
                mimetype: mediaType
            }, { quoted: m });
        } else {
            return reply(m.chat, "Not supported by this media!");
        }

    } catch (err) {
        console.log(err);
        reply(m.chat, mess.err);
    }
} break;


// Get url html code
case "get": {
await read("☑️");
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <link>`)
let data = await fetchJson(text)
reply(m.chat, JSON.stringify(data, null, 2))
} break;


// Clear
case "clear": {
await read("☑️");
if (!isDev && !isMod) return await only(mess.mod);
await reply(m.chat, textClear) // "textCear" Exports from ("./system/exports/clear.js")
} break;


// To Url
case "tourl": {
await read("☑️");
await reply(m.chat, "Maintenance!")
/*
if ((!m.quoted && !isMedia) || (!isMedia)) {
    return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image/Video/GIF>");
}
  
    try {
        let media;
        if (m.quoted) {
        media = await quoted.download();
        } else {
        media = await vikaru.downloadMediaMessage(m.message.imageMessage);
        }

        if (/image/.test(mime) || m.message?.imageMessage || /video/.test(mime) || m.message?.videoMessage || /image\/webp/.test(mime) || m.message?.stickerMessage || /image\/gif/.test(mime) || m.message?.gifMessage) {
            if (media.length > 100 * 1024 * 1024) return reply(m.chat, 'File size terlalu besar (Max 100MB)');

            let filename = `./${Date.now()}.${mime.split('/')[1]}`;
            fs.writeFileSync(filename, media);

            let formData = new FormData();
            formData.append('file', fs.createReadStream(media));
            formData.append('expirationOption', 'permanent');

            let res = await fetch('https://Nauval.mycdn.biz.id/upload', {
                method: 'POST',
                body: formData
            });

            let json = await res.json();
            fs.unlinkSync(media);

            if (json.success) {
                reply(m.chat, `*File Upload to URL* ️

* *Link :* ${json.fileUrl}
* *Expired :* Permanent`.trim());
            } else {
                reply(m.chat, `Upload gagal: ${json.message}`);
            }
        } else {
            reply(m.chat, 'Not supported by this media!');
        }
        
    } catch (e) {
        console.error(e);
        reply(m.chat, `*ERROR:* ${e.message}`);
    }*/
} break;


// Virtex
case "virtex": {
await read("☑️");
if (!isDev && !isMod && !isPremium) return await only(mess.prem)
if (!args[0]) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* 628xxxx`)
target = text.split("|")[0].replace(/[^0-9]/g, '')
let cekno = await vikaru.onWhatsApp(target + `@s.whatsapp.net`)
if (cekno.length == 0) return (`The number you entered is invalid!`)
vikaru.sendMessage(target+"@s.whatsapp.net", { text: textVirtex, key: m.key });
reply(m.chat, mess.done)
if (!isDev && !isMod && !isPremium) { limitAdd(m.sender, limit)} // Adding limits to database 
} break;


// Screenshot Website
case "ssweb": {
await read("☑️");
if (!text || !isUrl(text)) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <link>`);
vikaru.sendMessage(m.chat, { image: { url: 'https://image.thum.io/get/width/1900/crop/1000/fullpage/' + text }, caption: mess.done })
} break;


// Ip tracking 
case "iptracker":
case "iptracking": {
await read("🔎");
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <ip_address>`)

    try {
        let apiUrl = `http://ip-api.com/json/${encodeURIComponent(text)}?fields=61439`;
        let ipResponse = await fetchJson(apiUrl);

        if (!ipResponse || ipResponse.status !== "success") {
            return reply(m.chat, "⚠️ IP tidak ditemukan atau gagal dilacak!");
        }

        let hasil = `📍 *Hasil Pelacakan IP* 📍\n\n`;
        hasil += `🔹 *IP:* ${ipResponse.query}\n`;
        hasil += `🔹 *Negara:* ${ipResponse.country} (${ipResponse.countryCode})\n`;
        hasil += `🔹 *Wilayah:* ${ipResponse.regionName}\n`;
        hasil += `🔹 *Kota:* ${ipResponse.city}\n`;
        hasil += `🔹 *Kode Pos:* ${ipResponse.zip}\n`;
        hasil += `🔹 *Zona Waktu:* ${ipResponse.timezone}\n`;
        hasil += `🔹 *ISP:* ${ipResponse.isp}\n`;
        hasil += `🔹 *Organisasi:* ${ipResponse.org}\n`;
        hasil += `🔹 *Latitude:* ${ipResponse.lat}\n`;
        hasil += `🔹 *Longitude:* ${ipResponse.lon}\n`;

        await vikaru.sendMessage(m.chat, { text: hasil }, { quoted: m });

    } catch (error) {
        console.error("Error saat melacak IP:", error);
        reply(m.chat, "⚠️ Error saat melacak IP! Coba lagi nanti.");
    }
} break


//━━━━━━━━━━━[ GROUP MENU ]━━━━━━━━━━━━//


// Mute group on/off
case "mute": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isBotAdmins) return await only(mess.botadmin)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (args[0] == "on") {
vikaru.groupSettingUpdate(m.chat, "announcement").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err))
} else if (args[0] == "off") {
vikaru.groupSettingUpdate(m.chat, "not_announcement").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, "error"))
} else {
reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
}
} break;


// Silent group on/off
case "silent": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (args[0] == "on") {
if (isSilent) return reply(m.chat, "Already active")
silent.push(m.chat)
fs.writeFileSync("./main/system/database/silent.json", JSON.stringify(silent, null, 2))
reply(m.chat, mess.done)
} else if (args[0] == "off") {
if (!isSilent) return reply(m.chat, "Already inactive")
let anu = silent.indexOf(m.chat)
silent.splice(anu, 1)
fs.writeFileSync("./main/system/database/silent.json", JSON.stringify(silent, null, 2))
reply(m.chat, mess.done)
} else {
reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
}
} break;


// Kidnap all group members
case "culik": {
  await read("☑️");
  if (!isDev && !isMod) return await only(mess.mod);
  if (!isGroup) return reply(m.chat, mess.gc);

  async function getAllParticipantsFromAllGroups(vikaru) {
    try {
      const participants = (await Promise.all(
        Object.values(await vikaru.groupFetchAllParticipating()).map(g =>
          vikaru.groupMetadata(g.id).then(md => md.participants.map(p => p.id)).catch(e => [])
        )
      )).flat();
      return [...new Set(participants)]; // Mengembalikan array unik JID
    } catch (e) {
      reply(m.chat, e.message); // Menampilkan error jika terjadi
      return []; // Mengembalikan array kosong jika terjadi error
    }
  }

  try {
    const participants = await getAllParticipantsFromAllGroups(vikaru);
    if (participants.length > 0) {
      await vikaru.groupParticipantsUpdate(m.chat, participants, "add");
      reply(m.chat, mess.done);
    } else {
      // Tidak ada partisipan yang ditambahkan atau terjadi error
    }
  } catch (err) {
    reply(m.chat, err.message);
  }
} break;


// Add group participant
case "add": {
await read("☑️");    
    if (!m.isGroup) return await only(mess.gc);
    if (!isBotAdmins) return await only(mess.botadmin);
    if (!isDev && !isGroupAdmins) return await only(mess.admin);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
     
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Tambahkan anggota ke grup
    try {
        if (check.length == 0) { reply(m.chat, "This number is not registered on WhatsApp")
        } else { await vikaru.groupParticipantsUpdate(m.chat, [number+"@s.whatsapp.net"], "add").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, "Failed, the number is private!")); }
    } catch (err) {
        await reply(m.chat, "The number entered is invalid");
    }
} break;


// Kick group participant
case "kick": {
await read("☑️");
    if (!m.isGroup) return await only(mess.gc);
    if (!isBotAdmins) return await only(mess.botadmin);
    if (!isDev && !isGroupAdmins) return await only(mess.admin);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
     // Check if the number is registered on WhatsApp
     let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
        
     // Periksa apakah nomor dev
     const dev = devNumber + "@s.whatsapp.net";
    
    // Tambahkan anggota ke grup
    try {
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        if (dev.includes(number)) { reply(m.chat, "Dev number detected, Forbidden!")
        } else { await vikaru.groupParticipantsUpdate(m.chat, [number+"@s.whatsapp.net"], "remove").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, "Failed, the number is private!")); }
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Kick all group participant ( Be careful )
case "kickall": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc);
if (!isBotAdmins) return await only(mess.botadmin);
if (!isDev) return await only(mess.dev);
await vikaru.groupParticipantsUpdate(m.chat, participants.map(a => a.id), "remove").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err));
} break;


// Kick all group participant
case "kickme": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc);
if (!isBotAdmins) return await only(mess.botadmin);
await vikaru.groupParticipantsUpdate(m.chat, [m.sender], "remove").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err));
} break;


// Add as group admin
case "promote": {
await read("☑️");   
    if (!m.isGroup) return await only(mess.gc);
    if (!isBotAdmins) return await only(mess.botadmin);
    if (!isDev && !isGroupAdmins) return await only(mess.admin);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Tambahkan anggota ke grup
    try {
        if (check.length == 0) { reply(m.chat, "This number is not registered on WhatsApp")
        } else { await vikaru.groupParticipantsUpdate(m.chat, [number+"@s.whatsapp.net"], "promote").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err)); }
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Remove from admin group
case "demote": {
await read("☑️");   
    if (!m.isGroup) return await only(mess.gc);
    if (!isBotAdmins) return await only(mess.botadmin);
    if (!isDev && !isGroupAdmins) return await only(mess.admin);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Periksa apakah nomor dev
    const dev = devNumber + "@s.whatsapp.net";
    
    // Tambahkan anggota ke grup
    try {
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        if (dev.includes(number)) { reply(m.chat, "Dev number detected, Forbidden!")
        } else { await vikaru.groupParticipantsUpdate(m.chat, [number+"@s.whatsapp.net"], "demote").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err)); }
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Tag all group participants
case "tagall": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
let teks = `*# Note :* ${q ? q : "undefined"}\n\n`
for (let mem of participants) {
teks += `• @${mem.id.split("@")[0]}\n` }
vikaru.sendMessage(m.chat, {text: teks, mentions: participants.map(a => a.id)
}, {quoted: m })
} break;


// Hidetag
case "hidetag": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc);
if (!isBotAdmins) return await only(mess.botadmin);
if (!isDev && !isGroupAdmins) return await only(mess.admin);
vikaru.sendMessage(m.chat, { text : text ? text : 'Hide Tag!' , mentions: participants.map(a => a.id)}, { quoted: m })
} break;


// Polling
case "poll": {
await read("☑️");
let a = text.split("|").slice(1)
if (!a[1]) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Title | option1 | option2`)
if (a[12]) return reply(m.chat, "The selection options cannot be more than 12")
//if (checkDuplicate(a)) throw "Ada kesamaan isi dalam pesan!"

const pollMessage = {
name: text.split("|")[0],
values: a,
multiselect: false,
selectableCount: 1
}
await vikaru.sendMessage(m.chat, {
poll: pollMessage
}, { quoted: m })
}
break;


// Get group profile picture
case "getppgc": {
await read("☑️");
let image = await vikaru.profilePictureUrl(m.chat, "image").catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
await vikaru.sendMessage(m.chat, { image: { url: image }, mimetype: "image/jpeg", caption: mess.done }, { quoted: m });
} break;


// Set group profile picture
case "setppgc":
case "setppgrup":
case "setppgroup": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (!isBotAdmins) return await only(mess.botadmin)

  if ((!m.quoted && !isMedia) || (!isMedia)) {
    return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image>");
  }

  let media;
  if (m.quoted) {
    media = await quoted.download();
  } else {
    media = await vikaru.downloadMediaMessage(m.message.imageMessage);
  }

  try {
    if (/image/.test(mime) || m.message.imageMessage) {
      await vikaru.updateProfilePicture(m.chat, media ).then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err))
    } else {
      return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image>");
    }
  } catch (error) {
    console.log(error);
    reply(m.chat, "Not supported by this media.");
  } finally {
    //await fs.unlinkSync(media);
  }
} break;


// Set group name
case "setnamegc":
case "setnamagc": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (!isBotAdmins) return await only(mess.botadmin)
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);
await vikaru.groupUpdateSubject(m.chat, text).then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err))
} break;


// Set group description
case "setdesgc":
case "setdeskgc":
case "setdescgc":
case "setdeskripsigc":
case "setdescriptiongc": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (!isBotAdmins) return await only(mess.botadmin)
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);
await vikaru.groupUpdateDescription(m.chat, text).then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err))
} break;


// Group Link
case "gc":
case "grup":
case "group": {
await read("☑️");
await vikaru.sendMessage(m.chat, { text: textGroup,
            contextInfo: {
                isForwarded: false, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid, // 6289508899033@s.whatsapp.net
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: "[ 👥 ] - GROUP LIST",
                    body: "All Project",
                    //thumbnailUrl: imgUrl,
                    //thumbnailUrl: imgUrlRandom,
                    thumbnail: imgFile,
                    //thumbnailUrl: ppUrl,
                    //sourceUrl: `https://wa.me/6289513484928`,
                    sourceUrl: `${global.groupUrl}`,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
}, { userJid: m.chat, quoted: m })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
} break;


// Group information
case "infogc":
case "infogrup":
case "infogroup":
case "linkgc":
case "linkgrup":
case "linkgroup": 
case "idgc": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isBotAdmins) return await only(mess.botadmin)
let ppGc = await vikaru.profilePictureUrl(m.chat, "image").catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
let data = await vikaru.groupMetadata(m.chat)
let gclink = (`https://chat.whatsapp.com/`+await vikaru.groupInviteCode(m.chat))
var infogc =
` ☰  *\`GROUP INFO\`*
∘╌────────────────╌∘
▸ Jid : ${data.id}
▸ Made : ${moment(data.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}
▸ Owner : ${data.owner !== undefined ? "@" + data.owner.split`@`[0] : "Unknown"}
▸ Admins  : ${data.participants.filter(x => x.admin === "admin").length} participants
▸ Member : ${data.participants.filter(x => x.admin === null).length} participants
▸ Link : ${gclink}


> ▸ \`/group\` < _group list_`

await vikaru.sendMessage(m.chat, { text: infogc,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid, // 6289508899033@s.whatsapp.net
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: `${data.subject}`,
                    body: `${today} - [ ${data.participants.length} Participant ]`,
                    //thumbnailUrl: imgUrl,
                    //thumbnailUrl: imgUrlRandom,
                    //thumbnail: imgFile,
                    thumbnailUrl: ppGc,
                    //sourceUrl: `https://wa.me/6289513484928`,
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: m })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
} break;

// Antilink on/off
case "antilink": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (!isBotAdmins) return await only(mess.botadmin)
if (args[0] === "on") {
if (isAntilink) return reply(m.chat, "Already active")
antilink.push(m.chat)
fs.writeFileSync("./main/system/database/antilink.json", JSON.stringify(antilink, null, 2))
reply(m.chat, mess.done)
} else if (args[0] === "off") {
if (!isAntilink) return reply(m.chat, "Already inactive")
let anu = antilink.indexOf(m.chat)
antilink.splice(anu, 1)
fs.writeFileSync("./main/system/database/antilink.json", JSON.stringify(antilink, null, 2))
reply(m.chat, mess.done)
} else {
reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
}  
} break;


// Antitoxic on/off
case "antitoxic": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (!isBotAdmins) return await only(mess.botadmin)
if (args[0] === "on") {
if (isAntitoxic) return reply(m.chat, "Already active")
antitoxic.push(m.chat)
fs.writeFileSync("./main/system/database/antitoxic.json", JSON.stringify(antitoxic, null, 2))
reply(m.chat, mess.done)
} else if (args[0] === "off") {
if (!isAntitoxic) return reply(m.chat, "Already inactive")
let anu = antitoxic.indexOf(m.chat)
antitoxic.splice(anu, 1)
fs.writeFileSync("./main/system/database/antitoxic.json", JSON.stringify(antitoxic, null, 2))
reply(m.chat, mess.done)
} else {
reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
}  
} break;


// Welcome greetings for new group participants
case "welcome": {
await read("☑️");
const isWelcome = welcome.includes(m.chat) ? true : false
if (!m.isGroup) return await only(mess.gc)
if (!isDev && !isGroupAdmins) return await only(mess.admin)
if (args.length < 1) return reply(m.chat, "on/off?")
if (args[0] === "on") {
if (isWelcome) return reply(m.chat, "Already active")
welcome.push(m.chat)
fs.writeFileSync("./main/system/database/welcome.json", JSON.stringify(welcome, null, 2))
reply(m.chat, mess.done)
} else if (args[0] === "off") {
if (!isWelcome) return reply(m.chat, "Already inactive")
let anu = welcome.indexOf(m.chat)
welcome.splice(anu, 1)
fs.writeFileSync("./main/system/database/welcome.json", JSON.stringify(welcome, null, 2))
reply(m.chat, mess.done)
}
} break;


// Send a message to all group participants
case "pushcontact":
case "pushkontak": {
await read("☑️");
if (!m.isGroup) return await only(mess.gc)
if (!isDev) return await only(mess.dev)
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);

  async function sendMessageToAllWithProgress(groupId) {
    try {
      const gcData = await vikaru.groupMetadata(groupId);
      const totalParticipants = gcData.participants.length;
      let sentCount = 0;
      let lastProgressMessageId;

      function createProgressBar(totalContactsSent, totalParticipants) {
        const progressBarLength = 10;
        const progress = Math.floor((totalContactsSent / totalParticipants) * progressBarLength);
        const emptyBar = "░";
        const filledBar = "█";
        return `[${filledBar.repeat(progress)}${emptyBar.repeat(progressBarLength - progress)}] - [ ${totalContactsSent}/${totalParticipants} ]`;
      }

      const initialProgressMessage = await vikaru.sendMessage(m.chat, { text: createProgressBar(0, totalParticipants) });
      lastProgressMessageId = initialProgressMessage

      for (const participant of gcData.participants) {
        try {
          await vikaru.sendMessage(participant.id, { text: text });
          sentCount++;

          const progressBar = createProgressBar(sentCount, totalParticipants);
          await vikaru.sendMessage(m.chat, { text: progressBar, edit: lastProgressMessageId });

          // Tambahkan jeda 2 detik setelah setiap pengiriman pesan
          await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (error) {
          console.log(`Gagal mengirim pesan ke ${participant.name || participant.id}: ${error.message}`);
        }
      }

      await vikaru.sendMessage(m.chat, { text: mess.done, edit: lastProgressMessageId });

    } catch (error) {
      console.log("Error global:", error);
    }
  }

  await sendMessageToAllWithProgress(m.chat);
} break;


//━━━━━━━━━━━[ SYSTEM MENU ]━━━━━━━━━━━━//


// Upload story WhatsApp - mention group
/*case "upsw": {
  await read("☑️");
  if (!isDev) return await only(mess.dev);

  const helpMessage = `ⓘ *Send/Reply* <all_media>

- *Upload to Personal Status*
> Ex: *${prefix+command}* <text>

- *Upload to Groups (Tag Group)*
> Ex: *${prefix+command}* <text> | <xxxx@g.us>


> ▸ \`/listgc\` < _all group list_`;

  if (!text || !text && !m.quoted && !m.message.imageMessage && !m.message.videoMessage && !m.message.stickerMessage) {
    return reply(m.chat, helpMessage);
  }

  const [caption, groups] = text.split("|");
  const jids = groups?.split(" ").filter(id => id.endsWith("@g.us")) || [];
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || "";
  let media = null;

  try {
    media = m.quoted ? await quoted.download() : m.message.imageMessage ? await vikaru.downloadMediaMessage(m.message.imageMessage) : m.message.videoMessage ? await vikaru.downloadMediaMessage(m.message.videoMessage) : m.message.stickerMessage ? await vikaru.downloadMediaMessage(m.message.stickerMessage) : null;
  } catch (error) {
    console.error("Gagal mengunduh media:", error);
    reply(m.chat, "This media is not supported! ( default ).");
    media = { url: "https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg" };
  }

  //const statusJidList = [...new Set([...jids, ...Object.values(store.contacts).map(c => c?.id).filter(id => id?.endsWith("@s.whatsapp.net"))])];
  
  try {
    const BackgroundColor = ['#f68ac9', '#6cace4', '#f44336', '#4caf50', '#ffeb3b', '#9c27b0', '#0d47a1', '#03a9f4', '#9e9e9e', '#ff9800', '#000000', '#ffffff', '#008080', '#FFC0CB', '#A52A2A', '#FFA07A', '#FF00FF', '#D2B48C', '#F5DEB3', '#FF1493', '#B22222', '#00BFFF', '#1E90FF', '#FF69B4', '#87CEEB', '#20B2AA', '#8B0000', '#FF4500', '#48D1CC', '#BA55D3', '#00FF7F', '#008080', '#191970', '#FF8C00', '#9400D3', '#FF00FF', '#8B008B', '#2F4F4F', '#FFDAB9', '#BDB76B', '#DC143C', '#DAA520', '#696969', '#483D8B', '#FFD700', '#C0C0C0'];
    const pickedColor = BackgroundColor[Math.floor(Math.random() * BackgroundColor.length)];
    let participants = [];
    let totalParticipants = 0;
    let uploadType = jids.length ? "Group" : "Private"; // Menentukan jenis upload
  
    if (jids.length) {
        try {
          const metadata = await vikaru.groupMetadata(jids);
          //participants = [...participants, ...metadata.participants.map(a => a.id)];
          participants = [...new Set([...jids, ...Object.values(store.contacts).map(c => c?.id).filter(id => id?.endsWith("@s.whatsapp.net"))])];
          //participants = (await vikaru.groupMetadata(jids)).participants.map((a) => a.id)
          totalParticipants += metadata.participants.length;
        } catch (error) {
          console.error(`Failed to get group metadata ${jidList}: ${error}`);
          reply(m.chat, `Failed to get group metadata ${jidList}.\nThis group will be skipped.`);
        }
    } else {
      participants = Object.values(store.contacts).map(c => c?.id).filter(id => id?.endsWith("@s.whatsapp.net"));
      totalParticipants = participants.length;
    }

    let msgOptions = {};
    if (media) {
      const mediaType = mime.split("/")[0];
      if (mediaType === "image") {
        msgOptions = { image: media, caption: caption || "" };
      } else if (mediaType === "video") {
        msgOptions = { video: media, caption: caption || "", mimetype: 'video/mp4', gifPlayback: mime.includes('gif') };
      } else if (mediaType === "sticker") {
        if(media.url){
          msgOptions = { image: media.url, caption: caption || "" };
        } else {
          const stickerImage = await vikaru.sendMessage(m.chat, { image: media }, { quoted: m });
          msgOptions = { image: stickerImage.message.imageMessage.url, caption: caption || "" };
        }
      } else if (mediaType === "audio") {
        msgOptions = { audio: media, mimetype: 'audio/mpeg', ptt: true };
      } else {
        msgOptions = { image: { url: "https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg" }, caption: caption || "" };
      }
    } else {
      msgOptions = { text: caption || "" };
    }
    
    // Perubahan: Membedakan pengiriman pribadi dan grup
    if (jids.every((jid) => !jid.endsWith("@g.us"))) {
      await vikaru.sendMessage("status@broadcast", msgOptions, {
        backgroundColor: pickedColor,
        textArgb: 0xffffffff,
        font: 0,
        statusJidList: participants,
      });
    } else {
      // Pengiriman grup
      await vikaru.sendMessage("status@broadcast", msgOptions, {
        backgroundColor: pickedColor,
        textArgb: 0xffffffff,
        font: 0,
        statusJidList: participants,
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: jids.map((jid) => ({
                  tag: "to",
                  attrs: { jid },
                  content: undefined,
                })),
              },
            ],
          },
        ],
      });
    }
    
    /*jids.map((jid) => {
        let type = jid.endsWith("@g.us") ? "groupStatusMentionMessage" : "statusMentionMessage";
        return vikaru.relayMessage(
          jid,
          {
            [type]: {
              message: {
                protocolMessage: {
                  key: msg.key,
                  type: 25,
                },
              },
            },
          },
          {
            additionalNodes: [
              {
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined,
              },
            ],
          }
        );
      })*/
/*
    let replyMessage = `\`Story successfully uploaded\`\n- Upload : ${uploadType}\n- Contact : ${participants.length}`;
    
    if (uploadType === "Group") {
        replyMessage += `\n- Group : ${jids.length}\n- Participant : ${totalParticipants}`;
    }

    return reply(m.chat, replyMessage);
  } catch (error) {
    console.error(error);
    reply(m.chat, mess.err);
  }
} break;*/


case "upsw": {
  await read("☑️");
  if (!isDev && !isMod) return await only(mess.mod);
  if (!text || !text && !m.quoted && !m.message.imageMessage && !m.message.videoMessage && !m.message.stickerMessage && !m.message.audioMessage) {
    return reply(m.chat, 
`ⓘ *Send/Reply* <all_media>

- *Upload and mention sw for all group*
> Ex: *${prefix + command}* <teks>

- *Upload and mention sw for groups*
> Ex: *${prefix + command}* <teks> | <xxxx@g.us>


> ▸ \`/listgc\` < _list groups_`);
  }

  let caption = "";
  let jids = [];

  if (text.includes("|")) {
    const parts = text.split("|");
    caption = parts[0].trim();
    jids = parts[1].trim().split(" ").filter((id) => id.endsWith("@g.us"));
  } else {
    const allGroup = Object.keys(store.chats).filter((id) => id.endsWith("@g.us"));
    jids = allGroup
  }
  
  let media = null;
  let mime = null;

  try {
    if (m.quoted) {
      media = await quoted.download();
      mime = m.quoted.mtype === 'stickerMessage' ? 'image/webp' : m.quoted.mtype === 'imageMessage' ? 'image/jpeg' : m.quoted.mtype === 'videoMessage' ? 'video/mp4' : m.quoted.mtype === 'audioMessage' ? 'audio/ogg; codecs=opus' : 'unknown';
    } else if (m.message.imageMessage) {
      media = await vikaru.downloadMediaMessage(m.message.imageMessage);
      mime = m.message.imageMessage.mimetype;
    } else if (m.message.videoMessage) {
      media = await vikaru.downloadMediaMessage(m.message.videoMessage);
      mime = m.message.videoMessage.mimetype;
    } else if (m.message.stickerMessage) {
      media = await vikaru.downloadMediaMessage(m.message.stickerMessage);
      mime = m.message.stickerMessage.mimetype;
    } else if (m.message.audioMessage) {
      media = await vikaru.downloadMediaMessage(m.message.audioMessage);
      mime = m.message.audioMessage.mimetype;
    }
  } catch (error) {
    console.error("Failed to download media:", error);
    reply(m.chat, "Media not supported or failed to download!");
    media = { url: "https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg" };
  }

  const statusJidList = [...new Set([...jids, ...Object.values(store.contacts).map((c) => c?.id).filter((id) => id?.endsWith("@s.whatsapp.net"))])];

  try {
    if (media) {
      if (/image/.test(mime)) {
        await vikaru.uploadStory(statusJidList, { image: media, caption });
      } else if (/video/.test(mime) || /gif/.test(mime)) {
        await vikaru.uploadStory(statusJidList, { video: media, caption });
      } else if (/audio/.test(mime)) {
        await vikaru.uploadStory(statusJidList, { audio: media });
      } else {
        return reply(m.chat, "Media not supported!");
      }
    } else {
      const BackgroundColor = ['#f68ac9', '#6cace4', '#f44336', '#4caf50', '#ffeb3b', '#9c27b0', '#0d47a1', '#03a9f4', '#9e9e9e', '#ff9800', '#000000', '#ffffff', '#008080', '#FFC0CB', '#A52A2A', '#FFA07A', '#FF00FF', '#D2B48C', '#F5DEB3', '#FF1493', '#B22222', '#00BFFF', '#1E90FF', '#FF69B4', '#87CEEB', '#20B2AA', '#8B0000', '#FF4500', '#48D1CC', '#BA55D3', '#00FF7F', '#008080', '#191970', '#FF8C00', '#9400D3', '#FF00FF', '#8B008B', '#2F4F4F', '#FFDAB9', '#BDB76B', '#DC143C', '#DAA520', '#696969', '#483D8B', '#FFD700', '#C0C0C0'];
      const pickedColor = BackgroundColor[Math.floor(Math.random() * BackgroundColor.length)];
      await vikaru.uploadStory(statusJidList, { text: caption, backgroundColor: pickedColor, font: Math.floor(Math.random() * 9) });
    }

    const totalParticipants = (await Promise.all(jids.map(async (jid) => (await vikaru.groupMetadata(jid)).participants.length))).reduce((acc, count) => acc + count, 0);

    let replyMessage = `\`Story Successfully Uploaded\`\n- Group : ${jids.length}\n- Participants : ${totalParticipants}\n- Contacts : ${statusJidList.length}`;

    return reply(m.chat, replyMessage);
  } catch (error) {
    console.error(error);
    reply(m.chat, mess.err);
  }
} break;


// Upload notification to chenel
case "upch": {
    await read("☑️");
    if (!isDev) return await only(mess.dev);
    if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);

    await vikaru.sendMessage(global.newsletter.jid, {
        text: text,
        contextInfo: {
            externalAdReply: {
                title: `Pesan dari ${pushname}`,
                body: "Message to Newsletter",
                thumbnailUrl: imgUrl,
                showAdAttribution: true,
                renderLargerThumbnail: false,
            }
        }
    });

    m.reply(mess.done);
} break;


// Save text into save.json
case "save": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (!args[0]) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <text>`)
input = text; 
fs.writeFileSync("./main/system/database/save.json", JSON.stringify(input, null, 2));
reply(m.chat, mess.done)
} break;


// Reset all limit all user 
case "resetlimit": {
await read("☑️");
if (!isDev) return reply(m.chat, mess.dev);
function resetLimits() {
  try {
    const data = JSON.parse(fs.readFileSync('./main/system/database/limit.json', 'utf8'));
    data.forEach((user) => {
      user.limit = limitCount;
    });
    fs.writeFileSync('./main/system/database/limit.json', JSON.stringify(data, null, 2));
    reply(m.chat, mess.done);
    console.log('All user limits were successfully reset.');
  } catch (error) {
    console.error('An error occurred while resetting the limit:', error);
  }
}
resetLimits();
} break;


// Prefix on/off
case "prefix": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (args[0] === "on") {
if (setting.prefix === true) return reply(m.chat, "Already active")
setting.prefix = true
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2))
reply(m.chat, mess.done)
} else if (args[0] === "off") {
if (setting.prefix === false) return reply(m.chat, "Already inactive")
setting.prefix = false
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2))
reply(m.chat, mess.done)
} else {
reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
}
} break;


// Set Menu Bot
case "setmenu": {
    await read("☑️");
    if (!isDev) return await only(mess.dev);
    if (args.length < 1) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <1-5>`);

    if (text === "1") {
        if (setmenu.menu1 === true) return reply(m.chat, "Already active");
        setmenu.menu1 = true;
        setmenu.menu2 = false;
        setmenu.menu3 = false;
        setmenu.menu4 = false;
        setmenu.menu5 = false;
        fs.writeFileSync("./main/settings/setmenu.json", JSON.stringify(setmenu, null, 2));
        reply(m.chat, mess.done);

    } else if (text === "2") {
        if (setmenu.menu2 === true) return reply(m.chat, "Already active");
        setmenu.menu1 = false;
        setmenu.menu2 = true;
        setmenu.menu3 = false;
        setmenu.menu4 = false;
        setmenu.menu5 = false;
        fs.writeFileSync("./main/settings/setmenu.json", JSON.stringify(setmenu, null, 2));
        reply(m.chat, mess.done);

    } else if (text === "3") {
        if (setmenu.menu3 === true) return reply(m.chat, "Already active");
        setmenu.menu1 = false;
        setmenu.menu2 = false;
        setmenu.menu3 = true;
        setmenu.menu4 = false;
        setmenu.menu5 = false;
        fs.writeFileSync("./main/settings/setmenu.json", JSON.stringify(setmenu, null, 2));
        reply(m.chat, mess.done);

    } else if (text === "4") {
        if (setmenu.menu4 === true) return reply(m.chat, "Already active");
        setmenu.menu1 = false;
        setmenu.menu2 = false;
        setmenu.menu3 = false;
        setmenu.menu4 = true;
        setmenu.menu5 = false;
        fs.writeFileSync("./main/settings/setmenu.json", JSON.stringify(setmenu, null, 2));
        reply(m.chat, mess.done);

    } else if (text === "5") {
        if (setmenu.menu5 === true) return reply(m.chat, "Already active");
        setmenu.menu1 = false;
        setmenu.menu2 = false;
        setmenu.menu3 = false;
        setmenu.menu4 = false;
        setmenu.menu5 = true;
        fs.writeFileSync("./main/settings/setmenu.json", JSON.stringify(setmenu, null, 2));
        reply(m.chat, mess.done);

    } else {
        await reply(m.chat, `> ⓘ Only until <1-5>`);
    }
} break;


// Jadi bot
case "startbot":
case "jadibot": {
    await read("🔌");
    m.reply("Maintenance!");
/*    if (!isDev) return m.reply(mess.dev);
    if (!args[0].replace(/[^0-9]/g, '')) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <wa_numbet>`);

    const { multisession, startdata } = require("./system/multisession.js");
    const sessionPath = `./session/../${text}`;

    if (fs.existsSync(text)) {
        return reply(m.chat, "Sesi ini sudah terdaftar!");
    }

    try {
        const [result] = await vikaru.onWhatsApp(text + "@s.whatsapp.net");
        
        if (!result || !result.exists) {
            return reply(m.chat, "Nomor ini tidak terdaftar di WhatsApp.");
        }

        await multisession(vikaru, text);
        await sleep(3500);

        const sessionData = global.startdata.find(item => item.session === phoneNumber);
        if (sessionData && sessionData.code) {
            reply(m.chat, `Kode Pairing: ${sessionData.code}`);
        } else {
            reply(m.chat, "Gagal mendapatkan kode pairing.");
        }
    } catch (error) {
        console.error("Error starting bot:", error);
        reply(m.chat, "Error saat memulai bot.");
    }*/
} break;

			
// Auto Read on/off
case "autoread": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (args.length < 1) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
if (q === "on") {
if (setting.autoread === true) return reply(m.chat, "Already active")
setting.autoread = true; 
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2));
reply(m.chat, mess.done)
} else if (q === "off") {
if (setting.autoread === false) return reply(m.chat, "Already inactive")
setting.autoread = false; 
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2));
reply(m.chat, mess.done)
}
} break;


// Auto Read WhatsApp Status on/off
case "autoreadsw": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (args.length < 1) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
if (q === "on") {
if (setting.autoreadsw === true) return reply(m.chat, "Already active")
setting.autoreadsw = true; 
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2));
reply(m.chat, mess.done)
} else if (q === "off") {
if (setting.autoreadsw === false) return reply(m.chat, "Already inactive")
setting.autoreadsw = false; 
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2));
reply(m.chat, mess.done)
}
} break;


// Anti Call on/off
case "anticall": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (args.length < 1) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* on/off`)
if (q === "on") {
if (setting.anticall === true) return reply(m.chat, "Already active")
setting.anticall = true; 
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2));
reply(m.chat, mess.done)
} else if (q === "off") {
if (setting.anticall === false) return reply(m.chat, "Already inactive")
setting.anticall = false; 
fs.writeFileSync("./main/settings/setting.json", JSON.stringify(setting, null, 2));
reply(m.chat, mess.done)
}
} break;


// Add command
case 'addcmd': 
case 'setcmd':
if (!isOwner && !mek.key.fromMe) return reply(mess.only.ownerB)
if (isQuotedSticker) {
if (!c) return reply(`Penggunaan : ${command} cmdnya dan tag stickernya`)
var kodenya = mek.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage.fileSha256.toString('base64')
addCmd(kodenya, c)
reply("Done Bwang")
} else {
reply('tag stickenya')
}
break
case 'delcmd':
if (!isOwner && !mek.key.fromMe) return reply(mess.only.ownerB)
if (!isQuotedSticker) return reply(`Penggunaan : ${command} tagsticker`)
var kodenya = mek.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage.fileSha256.toString('base64')
scommand.splice(getCommandPosition(kodenya), 1)
fs.writeFileSync('./database/scommand.json', JSON.stringify(scommand))
reply("Done Bwang")
break
case 'listcmd':
if (!isOwner && !mek.key.fromMe) return reply(mess.only.ownerB)
let teksnyee = `\`\`\`「 LIST CMD STIC 」\`\`\``
let cemde = [];
for (let i of scommand) {
cemde.push(i.id)
teksnyee += `\n\n*⬣ ID :* ${i.id}\n*⬣ Cmd :* ${i.chats}`
}
reply(teksnyee)
break


// Set bot name
case "setnamebot":
case "setnamabot": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <text>`);
await vikaru.updateProfileName(text).then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err))
} break;


// Set bot profile picture
case "setppbot":
case "setppvika":
case "setppvikaru": {
await read("☑️");
if (!isDev) return await only(mess.dev)

  if ((!m.quoted && !isMedia) || (!isMedia)) {
    return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image>");
  }

  let media;
  if (m.quoted) {
    media = await quoted.download();
  } else {
    media = await vikaru.downloadMediaMessage(m.message.imageMessage);
  }

  try {
    if (/image/.test(mime) || m.message.imageMessage) {
      await vikaru.updateProfilePicture(botNumber, media ).then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err))
    } else {
      return reply(m.chat, "> ⓘ Ex: *Send/Reply* <Image>");
    }
  } catch (error) {
    console.log(error);
    reply(m.chat, "Not supported by this media.");
  } finally {
    //await fs.unlinkSync(media);
  }
} break;


// Block contact
case "block": {
await read("☑️");
    if (!isDev && !isMod) return await only(mess.mod);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Periksa apakah nomor dev
    const dev = devNumber + "@s.whatsapp.net";
    
    // Tambahkan anggota ke grup
    try {
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        if (dev.includes(number)) { reply(m.chat, "Dev number detected, Forbidden!")
        } else { vikaru.updateBlockStatus(number+"@s.whatsapp.net", "block").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err)); }
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Unblock contact
case "unblock": {
await read("☑️"); 
    if (!isDev && !isMod) return await only(mess.mod);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Tambahkan anggota ke grup
    try {
        if (check.length == 0) { reply(m.chat, "This number is not registered on WhatsApp")
        } else { await vikaru.updateBlockStatus(number+"@s.whatsapp.net", "unblock").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, mess.err)); }
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Get case code
case "case":
case "getcase": {
    await read("☑️");
    if (!isDev) return await only(mess.dev);
    if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* menu`);

    try {
        const fileContent = fs.readFileSync("./main/vikaru.js", "utf-8");
        const startIndex = fileContent.indexOf(`case "${text}"`);

        if (startIndex === -1) {
            return reply(m.chat, `Case *${text}* not found!`);
        }

        const caseContent = fileContent.substring(startIndex);
        const endIndex = caseContent.indexOf("break");

        if (endIndex === -1) {
            return reply(m.chat, "Error: 'break' statement not found in case block.");
        }

        const caseBlock = caseContent.substring(0, endIndex).trim();
        const formattedCase = `${caseBlock} break;`;

        await vikaru.sendMessage(m.chat, { text: formattedCase,
            contextInfo: {
                isForwarded: true, 
                mentionedJid: [m.sender], 
	            forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid, // 6289508899033@s.whatsapp.net
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},
                externalAdReply: {
                    title: `Getcase • ${global.version}`,
                    body: author,
                    thumbnail: imgFile,
                    sourceUrl: `${global.sosmed}`,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: qContact })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
    } catch (error) {
        console.error("Error in getcase:", error);
        reply(m.chat, "An error occurred while processing your request.");
    }
} break;



// Add moderator
case "addmod":
case "addmoderator": {
await read("☑️");
    if (!isDev) return await only(mess.dev);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is in the database
    const dbMod = contributor.includes(number) ? true : false
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")

    // Add moderators to the list and write to JSON
    try {
        if (dbMod) return reply(m.chat, `Already contributor`)
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        contributor.push(number); // Spread operator to add individual numbers
        fs.writeFileSync("./main/system/database/moderator.json", JSON.stringify(contributor));
        
        // Send notification message
        await vikaru.sendMessage(number + "@s.whatsapp.net", {
                image: { url: `https://telegra.ph/file/4a18ce660b79afea0058a.jpg` },
                caption: "You are now moderator!"
            }, { quoted: m });

        reply(m.chat, mess.done);
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Delete Moderator
case "delmod":
case "delmoderator": {
await read("☑️");
    if (!isDev) return await only(mess.dev);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is in the database
    const dbMod = contributor.includes(number) ? true : false
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Matching numbers with database
    let del = contributor.indexOf(number)

    // Delete moderators to the list and write to JSON
    try {
        if (!dbMod) return reply(m.chat, `This number is not moderator`)
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        contributor.splice(del, 1)
        fs.writeFileSync("./main/system/database/moderator.json", JSON.stringify(contributor));

        // Send notification message
        await vikaru.sendMessage(number + "@s.whatsapp.net", {
                image: { url: `https://telegra.ph/file/4a18ce660b79afea0058a.jpg` },
                caption: "You are now not moderator!"
            }, { quoted: m });

        reply(m.chat, mess.done);
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// List Moderator
case "listmod":
case "listmoderator": {
await read("☑️");
const listmoderator = JSON.parse(fs.readFileSync("./main/system/database/moderator.json", "utf8"));

let teks = "*List Moderator :*\n\n";

if (listmoderator.length === 0) {
  teks += "Not found!";
} else {
  for (let number of listmoderator) {
    teks += `> ${number}\n`;
  }
}

await vikaru.sendMessage(m.chat, { text: teks }, { quoted: m });
} break;


// Add Premiums
case "addprem":
case "addpremium": {
await read("☑️");
    if (!isDev) return await only(mess.dev);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
    // Check if the number is in the database
    const dbPrem = premium.includes(number) ? true : false
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")

    // Add premium to the list and write to JSON
    try {
        if (dbPrem) return reply(m.chat, "Already premium")
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        premium.push(number); // Spread operator to add individual numbers
        fs.writeFileSync("./main/system/database/premium.json", JSON.stringify(premium));

        // Send notification message
        await vikaru.sendMessage(number + "@s.whatsapp.net", {
                image: { url: `https://telegra.ph/file/4a18ce660b79afea0058a.jpg` },
                caption: "You are now premium user!"
            }, { quoted: m });

        reply(m.chat, mess.done);
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// Delete Premiums
case "delprem":
case "delpremium": {
await read("☑️");
    if (!isDev) return await only(mess.dev);

    // Extract phone numbers from various inputs
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0]; // Extract number from quoted sender
    } else if (m.mentionedJid.length > 0) {
        number = m.mentionedJid[0].split("@")[0]; // Extract numbers from mentioned JIDs
    } else if (text.trim().replace(/[^0-9]/g, '')) {
        number = text.trim().replace(/[^0-9]/g, ''); // Extract numbers from text
    } else {
        return reply(m.chat, `> ⓘ Ex: *${prefix+command}* Tag/reply/number`);
    }
    
     // Check if the number is in the database
    const dbPrem = premium.includes(number) ? true : false
    
    // Check if the number is registered on WhatsApp
    let check = await vikaru.onWhatsApp(number + "@s.whatsapp.net")
    
    // Matching numbers with database
    let del = premium.indexOf(number)

    // Delete premium to the list and write to JSON
    try {
        if (!dbPrem) return reply(m.chat, `This number is not premium`)
        if (check.length == 0) return reply(m.chat, "This number is not registered on WhatsApp")
        premium.splice(del, 1)
        fs.writeFileSync("./main/system/database/premium.json", JSON.stringify(premium));

        // Send notification message
        await vikaru.sendMessage(number + "@s.whatsapp.net", {
                image: { url: `https://telegra.ph/file/4a18ce660b79afea0058a.jpg` },
                caption: "You are now not premium user!"
            }, { quoted: m });

        reply(m.chat, mess.done);
    } catch (err) {
        await reply(m.chat, mess.err);
    }
} break;


// List Premium
case "listprem":
case "listpremium": {
await read("☑️");
const listpremium = JSON.parse(fs.readFileSync("./main/system/database/premium.json", "utf8"));

let teks = "*List Premium :*\n\n";

if (listpremium.length === 0) {
  teks += "Not found!";
} else {
  for (let number of listpremium) {
    teks += `> ${number}\n`;
  }
}

await vikaru.sendMessage(m.chat, { text: teks }, { quoted: m });
} break;


// Join group
case "joingc": {
    await read("☑️");
    if (!isDev) return await only(mess.dev)
    if (!text) {
        return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <group_link>`);
    }

    // Pemeriksaan apakah text adalah tautan grup WhatsApp menggunakan isUrl
    if (!isUrl(args[0]) && !args[0].includes('chat.whatsapp.com')) {
        return reply(m.chat, "Tautan yang Anda berikan bukan tautan grup WhatsApp yang valid.");
    }

    try {
        const inviteCode = args[0].split('https://chat.whatsapp.com/')[1]
        const res = await vikaru.groupAcceptInvite(inviteCode);
        if (res) {
            await reply(m.chat, mess.done);
        } else {
            reply(m.chat, `> ⓘ Ex: *${prefix + command}* <only_group_link>`);
        }
    } catch (err) {
        reply(m.chat, "Expired group / requires admin approval!");
        }
} break;


// Leave group
case "leavegc": {
await read("☑️");
if (!isDev) return await only(mess.dev)
if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix + command}* <xxxx@g.us>`);
await reply(text, "Access for this group has been removed, goodbye 👋🏻 ")
sleep(2000)
await vikaru.groupParticipantsUpdate(text, [botNumber], "remove").then((res) => reply(m.chat, mess.done)).catch((err) => reply(m.chat, "Failed, the number is private!"));
} break;


// List group
case "listgc":
case "listgrup":
case "listgroup": {
    await read("☑️");
    try {
        await reply(m.chat, mess.wait)
        let allGroups = await vikaru.groupFetchAllParticipating();
        let groupList = Object.values(allGroups);

        if (groupList.length === 0) {
            return reply(`Bot is not registered in any groups.`);
        }

        let cards = [];

        for (let g of groupList) {
            let data = await vikaru.groupMetadata(g.id);
            let ppGc = await vikaru.profilePictureUrl(g.id, "image").catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
            let admins = data.participants.filter(x => x.admin === "admin").length;
            let members = data.participants.filter(x => x.admin === null).length;
            let creationDate = moment(data.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss");
            let groupLink;

            try {
                groupLink = "https://chat.whatsapp.com/" + await vikaru.groupInviteCode(g.id);
            } catch (error) {
                groupLink = "Undefined! Bot is not admin"; // Link fallback jika bot bukan admin
            }

            cards.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `*${data.subject}*\n\n` +
                        `▸ ID: ${data.id}\n` +
                        `▸ Made: ${creationDate}\n` +
                        `▸ Owner: ${data.owner !== undefined ? "@" + data.owner.split`@`[0] : "Unknown"}\n` +
                        `▸ Admins: ${admins} participants\n` +
                        `▸ Member: ${members} participants`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: footer
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Group Metadata List:`,
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({ image: { url: ppGc } }, { upload: vikaru.waUploadToServer }))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Copy Link","copy_code":"${groupLink}"}`
                        },
                        {
                            name: "cta_copy",
                            buttonParamsJson: `{"display_text":"Copy Jid","copy_code":"${data.id}"}`
                        }
                    ]
                })
            });
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.newsletter.jid,
                                newsletterName: global.newsletter.name,
                                serverMessageId: -1
                            },
                            businessMessageForwardInfo: { businessOwnerJid: vikaru.decodeJid(vikaru.user.id) },
                            forwardingScore: 256,
                            externalAdReply: {
                                title: "List Grup",
                                thumbnailUrl: "",
                                sourceUrl: "",
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `*👥 Showing all groups :*`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: author
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });

        vikaru.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

    } catch (error) {
        console.log("❌ Failed to fetch group list:", error);
        await reply(m.chat, `⚠️ An error occurred while retrieving the group list...`);
    }
} break;


// Update user limit
case "addlimit": {
  await read("☑️");
  if (!isDev) return reply(m.chat, mess.dev);
  if (!text) return reply(m.chat, `> ⓘ Ex: *${prefix+command}* <628xxxx> | <amount>`);

  const parts = text.split("|");
  const userjid = parts[0].trim();
  const amount = parts[1].trim();

  if (!userjid.replace(/[^0-9]/g, '')) return reply(m.chat, "Invalid phone number.");
  if (!amount.replace(/[^0-9]/g, '')) return reply(m.chat, "Invalid limit amount.");

  function updateUserLimit(jid, newLimit) {
    try {
      const data = JSON.parse(fs.readFileSync('./main/system/database/limit.json', 'utf8'));
      const userIndex = data.findIndex(user => user.id === jid);

      if (userIndex !== -1) {
        data[userIndex].limit = parseInt(newLimit);
        fs.writeFileSync('./main/system/database/limit.json', JSON.stringify(data, null, 2));
        reply(m.chat, `\`CHANGE USER LIMITS\`\n- User: ${jid.split("@")[0]}\n- Limit: ${parseInt(newLimit)}`);
      } else {
        console.log(`ID: ${jid.split("@")[0]} undefined from database!`);
      }
    } catch (error) {
      console.error('An error occurred while updating user limits.:', error);
    }
  }
  updateUserLimit(userjid + "@s.whatsapp.net", amount);
} break;


// Cek limit
case "ceklimit": {
  await read("☑️");
  
  const userJid = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;

  try {
    const isRegistered = await vikaru.onWhatsApp(userJid);

    if (isRegistered && isRegistered.length > 0) {
      const limitResult = getLimit(userJid, limitCount, limit);

      if (limitResult) {
        reply(m.chat, `\`CHECK LIMIT\`\n- User: ${userJid.split("@")[0]}\n- Limit: ${isDev || isMod || isPremium ? "Infinity" : limitResult}`);
      } else {
        reply(m.chat, `Limit untuk ${userJid.split("@")[0]} tidak ditemukan.`);
      }
    } else {
      reply(m.chat, `${userJid} tidak terdaftar di WhatsApp.`);
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat cek limit:", error);
    reply(m.chat, mess.err);
  }
} break;


// Public Mode ( Delete all ignored numbers )
case "public": {
await read("☑️");
if (!setting.prefix) return reply(m.chat, "Please change /prefix to *on*")
if (!itsMe) throw reply(m.chat, "Bot only!")
vikaru.public = true
reply(m.chat, mess.done)
} break;


// Self Mode ( Ignore all numbers )
case "self": {
await read("☑️");
if (!isDev) return await only(mess.dev)
vikaru.public = false
reply(m.chat, mess.done)
} break;


// Delete message
case "delete":
case "del":
case "d": {
await read("☑️");
if (!isDev && !isMod && !isGroupAdmins) return await only(mess.admin)
if (!m.quoted) return reply(m.chat, "Reply the message!")
try {
if (m.isGroup && m.quoted.fromMe) {
await vikaru.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: m.isBotAdmins ? false : true, id: m.quoted.id, participant: m.quoted.sender } })
} else if (m.isGroup && !m.quoted.fromMe) {
if (!isBotAdmins) return await only(mess.botadmin)
await vikaru.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: m.quoted.id, participant: m.quoted.sender } })
} else {
await vikaru.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: m.quoted.id, participant: m.quoted.sender } })
}
} catch (e) { await reply(m.chat, mess.err) }
} break;


// Watermark
case "wm":
case "watermark":
case "dev":
case "developer":
case "sc":
case "script":
case "src":
case "source":
case "sourcecode": {
await read("⚡");
let textnya = "https://github.com/dcodemaxz/Vikaru-Bot"
await vikaru.sendMessage(m.chat, { text: textnya,
            contextInfo: {
                isForwarded: false, 
                mentionedJid: [m.sender], 
	           /*forwardedNewsletterMessageInfo: {
    newsletterJid: global.newsletter.jid,
    newsletterName: global.newsletter.name,
    serverMessageId: -1
},*/
                externalAdReply: {
                    title: "Vikaru-Bot",
                    body: "©dcodemaxz",
                    thumbnailUrl: "https://files.catbox.moe/ly216w.jpg",
                    sourceUrl: "https://wa.me/6289508899033/?text=Hello",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
}, { userJid: m.chat, quoted: qPayment })
 vikaru.relayMessage(m.key.remoteJid, m.chat, {
  messageId: m.key.id })
  
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/sc.mp3"), mimetype: "audio/mp4", ptt: true });
} break;


//-----------------------=× CLOSING CMD ×=-----------------------//


default:

// Reply if command does not exist
if (command) {
    try {
      const handler = fs.readFileSync('./main/vikaru.js', 'utf-8');
      const regex = /(case\s(.*?)[:])/g;
      const parse = handler.matchAll(regex);
      let temp = [],
        commands = [];
      for (const cmd of parse) {
        temp.push(cmd[2]);
      }
      temp
        .filter((v) => v.startsWith(`"`))
        .map((v) => commands.push(v.replace(new RegExp(`"`, 'g'), '')));
      temp
        .filter((v) => v.startsWith(`'`))
        .map((v) => commands.push(v.replace(new RegExp(`'`, 'g'), '')));
      /*temp
        .filter((v) => v.startsWith(`[`))
        .map((v) => commands.push(Array(v.split` `[0])));*/

      function getSimilarity(s1, s2) {
        const longer = s1.length > s2.length ? s1 : s2;
        const shorter = s1.length > s2.length ? s2 : s1;
        let same = 0;
        for (let i = 0; i < shorter.length; i++) {
          if (longer.indexOf(shorter[i]) > -1) {
            same++;
          }
        }
        return (same / longer.length) * 100;
      }

      let matcher = [];
      commands.forEach((cmd) => {
        const similarity = getSimilarity(command, cmd);
        if (similarity >= 60) {
          matcher.push({ string: cmd, accuracy: Math.round(similarity) });
        }
      });

      if (prefix && !commands.includes(command) && matcher.length > 0) {
        await read("❗");
        if (!m.isGroup || m.isGroup) {
          return reply(
            m.chat,
            `\`CMD SUGGESTION\`\n\n${matcher
              .map((v) => '➠ *' + (prefix ? prefix : '') + v.string + '* - [ ' + v.accuracy + '% ]')
              .join('\n')}`
          );
        }
      } else if (prefix && !commands.includes(command)){
        return false
      }
    } catch (error) {
      console.error('Error:', error);
      return m.reply('An error occurred while processing the command.');
    }
break };
  

// Eval 1 (=>)
if (budy.startsWith("=>")) {
  if (!isDev) return false;
  await read("⚙️");
  const code = budy.slice(3);
  try {
    const result = await eval(`(async () => { return ${code} })()`);
    if (result === undefined) {
      m.reply("The evaluation result is undefined!");
    } else {
      m.reply(util.format(result));
    }
  } catch (error) {
    if (error instanceof ReferenceError) {
      m.reply(`Undefined Variable: ${error.message}`);
    } else {
      m.reply(`Error:\n${error}`);
    }
  }
}

// Eval 2 (>>)
if (budy.startsWith(">>")) {
  if (!isDev) return false;
  await read("⚙️");
  const code = budy.trim().split(/ +/)[0];
  const expression = budy.trim().slice(code.length).trim();
  try {
    const result = await eval(`(async () => { ${code === ">>" ? "return" : ""} ${expression} })()`);
    if (result === undefined) {
      m.reply("The evaluation result is undefined!");
    } else {
      m.reply(require("util").format(result));
    }
  } catch (error) {
    if (error instanceof ReferenceError) {
      m.reply(`Undefined Variable: ${error.message}`);
    } else {
      m.reply(`Error:\n${error}`);
    }
  }
}

// Eval 3 ($)
if (budy.startsWith("$")) {
  if (!isDev) return false;
  await read("⚙️");
  const command = budy.slice(2);
  exec(command, (error, stdout, stderr) => {
    if (error) {
      if (error.code === 127) {
        m.reply(`Perintah tidak ditemukan: ${error.message}`);
      } else {
        m.reply(`Error:\n${error.message}\n\n${stderr}`);
      }
      return;
    }
    if (stdout) {
      m.reply(stdout);
      return;
    }
    if (stderr) {
      m.reply(stderr);
      return;
    }
    m.reply("Executed successfully with no output.");
  });
}

// Salam
if (!isCmd && budy.match(/assalamualaikum/i)) {
if (itsMe) return false
await read("🙏🏻");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/salam.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Good morning greetings ( Ohayo )
if (!isCmd && budy.match(/ohayo|goodmorning|good\smorning/i)) {
if (itsMe) return false
await read("👋🏻");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/ohayo.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Good Night greetings ( Oyasumi )
if (!isCmd && budy.match(/oyasumi|oyasuminasai|oyasumi\snasai|goodnight|good\snight/i)) {
if (itsMe) return false
await read("😴");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/oyasumi.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Goblok
if (!isCmd && budy.match(/goblok|gblk/i)) {
if (itsMe) return false
await read("🫢");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/heeh.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Baka
if (!isCmd && budy.match(/\bbaka\b/i)) {
if (itsMe) return false
await read("😝");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/baka.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Yareyare
if (!isCmd && budy.match(/yareyare|yare\syare/i)) {
if (itsMe) return false
await read("😫");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/yareyare.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Gambare
if (!isCmd && budy.match(/gamabre|gambaregambare|gambare\sgambare/i)) {
if (itsMe) return false
await read("🔥");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/gambare.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Gey
if (!isCmd && budy.match(/gay|gey/i)) {
if (itsMe) return false
await read("🏳️‍🌈");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/gey.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Moshi mossh
if (!isCmd && budy.match(/halo|hallo|moshimosh|moshi\smosh/i)) {
if (itsMe) return false
await read("👐🏻");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/moshimosh.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Nokoni koni
if (!isCmd && budy.match(/nikonikoni|nikoni\skoni|niko\snikoni|niko\sniko\sni/i)) {
if (itsMe) return false
await read("😊");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/nikonikoni.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// asautegondalimas
if (!isCmd && budy.match(/asautegondalimas/i)) {
if (itsMe) return false
await read("🤭");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/asautegondalimas.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Araara
if (!isCmd && budy.match(/araara|ara\sara/i)) {
if (itsMe) return false
await read("😚");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/araara.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Love you
if (!isCmd && budy.match(/lopyu|Lopyou|loveyou|love\nyou/i)) {
if (itsMe) return false
if (isDev | isMod | isPremium) {
await read("🫰🏻");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/lopyou.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
} else { 
await read("🐐");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/kambing.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}
}

// Sepuh
if (!isCmd && budy.match(/sepuh/i)) {
if (itsMe) return false
await read("🙇🏻‍♂️");
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync("./main/media/audio/sepuh.mp3"), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Greet ( Vika )
if (!isCmd && budy.match(/^(\bvika\b)$|^(\bvikaru\b)$|^(\bbot\b)$/i)) {
if (itsMe) return false
await read("🤗");
const audioFiles = ["iyakak", "oy", "kenapa", "adaapakak", "gamau", "lusiapa", "gakada", "kagaada", "goblok"];
function getRandomAudioFile() {
    const randomIndex = Math.floor(Math.random() * audioFiles.length);
    return audioFiles[randomIndex];
}
let randomAudio = getRandomAudioFile();
await vikaru.sendMessage(m.chat, { audio : fs.readFileSync(`./main/media/audio/${randomAudio}.mp3`), mimetype: "audio/mp4", ptt: true }, { quoted: m });
}

// Ai character ( quoted only ) ( Indonesian )
if (isAutoai) {
  if (!command && m.quoted && budy.startsWith('')) {
    if (itsMe) return false;
    if (m.quoted.sender === vikaru.decodeJid(vikaru.user.id)) {
      await read("💬");
      let prompt = `&prompt:Kamu bukan asisten/ai, kamu adalah seorang gadis lucu, elegan dan mempesona yang berumur 14 tahun bernama Vika atau Vikaru yang memiliki sifat seperti karakter Furina dari Genshin Impact, dengan kosa kata yang sangat sedikit dan singkat, menggemaskan dan juga cerewet. Lawan ngobrol kamu adalah ${pushname}&text:`;

      try {
        let { data } = await axios.get(`https://sandipbaruwal.onrender.com/gemini?prompt=${encodeURIComponent(prompt + m.text)}`);

        if (data.status === "error") {
          reply(m.chat, `Maaf, vika lagi cape kak 😥`);
        } else {
          reply(m.chat, data.answer);
        }

        // Log Ai Message to server
        console.log('');
        console.log(`${m.isGroup ? chalk.green("[💬] GC-AI") : chalk.blue("[📨] PC-AI")}   : [${chalk.bgCyan.black(` Chat-Ai `)}] at ${chalk.magenta(calender)}`);
        console.log("\x1b[90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━·>");
        console.log(`\x1b[37m› In        : \x1b[0m${m.isGroup ? groupName : "Private Chat"}`);
        console.log(`\x1b[37m› From      : \x1b[0m${m.chat}`);
        console.log(`\x1b[37m› Sender    : \x1b[0m${m.sender.split("@")[0]} > \x1b[33m${m.pushName ? m.pushName : " Undefined!"}\x1b[0m`);
        console.log(`\x1b[37m› Status    : \x1b[0m${senderStatus}`);
        console.log(`\x1b[37m› Chat      : \x1b[0m${m.text}\x1b[0m`);
        console.log('');

      } catch (error) {
        console.log(error);
        reply(m.chat, "Maaf, vika lagi cape kak 🥱");
      }
    }
  }
}


} // Switch Command

// Console log of sender messages ( default )
if (command) {
console.log('');
//${m.body || m.mtype}
console.log(`${m.isGroup ? `\x1b[32m[💬] GC-CMD\x1b[0m` : `\x1b[34m[📨] PC-CMD\x1b[0m`} : \x1b[37m[${chalk.bgCyan.black(` ${prefix+command} `)}]\x1b[0m at \x1b[35m${calender}\x1b[0m`);
console.log("\x1b[90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━·>");
console.log(`\x1b[37m› In        : \x1b[0m${m.isGroup ? groupName : "Private Chat"}`);
console.log(`\x1b[37m› From      : \x1b[0m${m.chat}`);
console.log(`\x1b[37m› Sender    : \x1b[0m${m.sender.split("@")[0]} > \x1b[33m${m.pushName ? m.pushName : " Undefined!"}\x1b[0m`);
console.log(`\x1b[37m› Autoai    : \x1b[0m${isAutoai ? "True" : "False"}`);
console.log(`\x1b[37m› Status    : \x1b[0m${senderStatus}`);
console.log(`\x1b[37m› Limit     : \x1b[0m${isDev || isMod || isPremium ? "Infinity" : getLimit(m.sender, limitCount, limit)}`);
console.log('');
// Reduce the limit of the database
if (!isDev && !isMod && !isPremium) {
limitDel(m.sender, limit);
}
};

// Try ( module exports )
} catch (err) {
  const errorKey = err.message + err.stack;
  const fatalErrorKey = err.message + err.stack;
  console.log(util.format(err));
  
  // Prioritaskan penanganan error fatal (ReferenceError)
  if (err instanceof ReferenceError) {
    if (!fatalErrorCache.has(fatalErrorKey)) {
      await vikaru.sendMessage(global.devNumber + "@s.whatsapp.net", { text: `*「 ❌ 」ERROR FATAL*\n\n${err}` }, { quoted: m });
      fatalErrorCache.set(fatalErrorKey, true);
      setTimeout(() => {
        fatalErrorCache.delete(fatalErrorKey);
      }, 60 * 1000); // 1 menit
    }
    
  } else { // Tangani error reguler jika bukan ReferenceError
    if (!errorCache.has(errorKey)) {
      await vikaru.sendMessage(global.devNumber + "@s.whatsapp.net", { text: util.format(err) }, { quoted: m });
      await sleep(2000);
      await vikaru.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      errorCache.set(errorKey, true);
      errorCache.delete(errorKey);
    }
  }
}

} // Module Exports


// Refreshing File After Recode/Editing
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log()
console.log(`› [ ${chalk.black(chalk.bgBlue(" Update Files "))} ] ▸ ${__filename}`)
delete require.cache[file]
require(file)
})