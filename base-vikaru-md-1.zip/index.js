/*
<•━━━━━━━━[ SOURCE CODE ]━━━━━━━━━•>

 • Developer : Maxz
 • Contact   : https://linktr.ee/dcodemaxz

<•━━━━━━━━━━━━━━━━━━━━━━━━━━━━━•>

 • [ NOTE ]
 - Thank you for supporting the developer by purchasing this script.
 - Please read the "© dcodemaxz" before using this script!
 
*/


const {
     default: makeWASocket,
     DisconnectReason,
     makeInMemoryStore,
     jidDecode,
     proto,
     getContentType,
     useMultiFileAuthState,
     getAggregateVotesInPollMessage,
     downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
     smsg,
     isUrl,
     generateMessageTag,
     appenTextMessage,
     getBuffer,
     getSizeMedia,
     fetchJson,
     await,
     sleep
} = require('./main/system/myfunction.js');
const {
     imageToWebp,
     imageToWebp3,
     videoToWebp,
     writeExifImg,
     writeExifImgAV,
     writeExifVid
} = require('./main/system/exif.js');
const {
     Boom
} = require('@hapi/boom');
const fs = require('fs');
const path = require('path');
const pino = require('pino');
const chalk = require('chalk');
const readline = require("readline");
const FileType = require('file-type');
const PhoneNumber = require('awesome-phonenumber');

// Require Settings
require('./main/settings/config.js');
let setting = JSON.parse(fs.readFileSync('./main/settings/setting.json'));
let welcome = JSON.parse(fs.readFileSync('./main/system/database/welcome.json'));

// Variable Calender
let d = new Date
let today = new Date().toLocaleDateString();
let calender = d.toLocaleDateString("id", {
     day: "numeric",
     month: "long",
     year: "numeric"
});

// Store
const store = makeInMemoryStore({
     logger: pino().child({
          level: 'silent',
          stream: 'store'
     })
});

// Request readline
const rl = readline.createInterface({
     input: process.stdin,
     output: process.stdout
});

// Request phone number
const question = (text) => {
     return new Promise((resolve) => {
          rl.question(text, resolve)
     })
};

// Start Bot Vikaru-Md
async function vikarustart(sessionPath) {
     if (!sessionPath) {
          session = global.session;
     } else {
          session = sessionPath;
     }

     const {
          state,
          saveCreds
     } = await useMultiFileAuthState(`./session/${session}`); // session name

     // Socket Vikaru
     const vikaru = makeWASocket({
          logger: pino({
               level: "silent"
          }),
          printQRInTerminal: false, // false = Pairing code
          auth: state,
          connectTimeoutMs: 60000,
          defaultQueryTimeoutMs: 0,
          keepAliveIntervalMs: 10000,
          emitOwnEvents: true,
          fireInitQueries: true,
          generateHighQualityLinkPreview: true,
          syncFullHistory: true,
          markOnlineOnConnect: true,
          browser: ["Ubuntu", "Chrome", "20.0.04"]
     });

     // Input phone number to pairing
     if (!vikaru.authState.creds.registered) {
          let retryCount = 0;
          const maxRetries = 3;
          let passwordCorrect = false;

          while (retryCount < maxRetries && !passwordCorrect) {
               console.log();
               let inputPassword = await question('› Enter Passwd : ');

               if (inputPassword === "4331") {
                    passwordCorrect = true;
                    let phoneNumber = await question('› Enter Number : ');
                    let pairing = await vikaru.requestPairingCode(phoneNumber);
                    let code = pairing?.match(/.{1,4}/g)?.join("-") || pairing;
                    console.log(`› Pairing Code : ${chalk.black(chalk.bgGreen(` ${code} `))}`);
               } else {
                    retryCount++;
                    if (retryCount < maxRetries) {
                         console.log();
                         console.log(`› [ ${chalk.black(chalk.bgYellowBright(' Pw incorrect '))} ] ▸ Try again, attempts reached - [ ${maxRetries - retryCount} ]`);
                    }
               }
          }

          if (!passwordCorrect) {
               console.log();
               console.log(`› [ ${chalk.black(chalk.bgRedBright(' Access denied '))} ] ▸ Maximum attempts reached!`);
               fs.writeFileSync("🔥 WARNING 🔥",
                    `<•━━━━━━━━[ SOURCE CODE ]━━━━━━━━━•>

 • Developer : Maxz
 • Contact   : https://linktr.ee/dcodemaxz

<•━━━━━━━━━━━━━━━━━━━━━━━━━━━━━•>`);
               const files = fs.readdirSync(__dirname);
               for (const file of files) {
                    const filePath = path.join(__dirname, file);
                    if (file !== "🔥 WARNING 🔥") {
                         fs.rmSync(filePath, {
                              recursive: true,
                              force: true
                         });
                    }
               }
               process.exit();
          }
          console.log();
          await sleep(1000);
          console.log(`› [ ${chalk.black(chalk.bgCyan(' Adds Session '))} ] ▸ Waiting Pairing To WhatsApp...`);
     };


     // true : Bot can be used by everyone
     vikaru.public = true;

     // Accessing whatsapp server memory and message
     store.bind(vikaru.ev);

     // Taking message
     vikaru.ev.on('messages.upsert', async chatUpdate => {
          try {
               mek = chatUpdate.messages[0]
               if (!mek.message) return
               mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message

               // Auto Read status WhatsApp
               if (setting.autoreadsw && mek.key && mek.key.remoteJid === 'status@broadcast') {
                    await vikaru.readMessages([mek.key])
                    console.log()
                    console.log(`\x1b[1;32m☰ STATUS  : \x1b[0mat \x1b[0;32m${calender}\x1b[0m`)
                    console.log(`\x1b[0m=-------------------------------------------=`)
                    console.log("› Username:", mek.pushName ? mek.pushName : "Unknown")
                    console.log("› Captions:", mek.message.extendedTextMessage?.text || null)
                    console.log()
               };
               if (!vikaru.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
               if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
               const m = smsg(vikaru, mek, store)

               // Taking commands from case ( vikaru.js )
               require("./main/vikaru.js")(vikaru, m, chatUpdate, mek, store, setting, welcome)
          } catch (err) {
               console.log(err)
          }
     });

     // Get Message Key
     async function getMessage(key) {
          if (store) {
               const msg = await store.loadMessage(key.remoteJid, key.id)
               return msg?.message
          }
          return {
               conversation: botName
          }
     }

     // Response Polling
     vikaru.ev.on('messages.update', async chatUpdate => {
          for (const {
                    key,
                    update
               }
               of chatUpdate) {
               if (update.pollUpdates && key.fromMe) {
                    const pollCreation = await getMessage(key)
                    if (pollCreation) {
                         const pollUpdate = await getAggregateVotesInPollMessage({
                              message: pollCreation,
                              pollUpdates: update.pollUpdates,
                         })
                         var toCmd = pollUpdate.filter(v => v.voters.length !== 0)[0]?.name
                         if (toCmd == undefined) return
                         const prefixRegex = /^[./#!]/; // Prefix
                         const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : ".";
                         var prefCmd = prefix + toCmd
                         vikaru.appenTextMessage(prefCmd, chatUpdate)
                    }
               }
          }
     })

     // Loading store data from database.json
     function readData() {
          try {
               const data = fs.readFileSync(path.join(__dirname, './main/system/database/database.json'));
               return JSON.parse(data);
          } catch (error) {
               return {
                    contacts: {},
                    chats: {}
               };
          }
     }

     // Uploading store data to database.json
     function writeData(data) {
          fs.writeFileSync(path.join(__dirname, './main/system/database/database.json'), JSON.stringify(data, null, 2));
     }

     // Taking contact
     vikaru.ev.on('contacts.upsert', update => {
          const data = readData();
          for (let contact of update) {
               let id = contact.id;
               data.contacts[id] = {
                    ...(contact || {}),
                    isContact: true
               };
               if (store && store.contacts) store.contacts[id] = {
                    ...(contact || {}),
                    isContact: true
               };
          }
          writeData(data);
     });

     // Updating contacts
     vikaru.ev.on('contacts.update', update => {
          const data = readData();
          for (let contact of update) {
               let id = contact.id;
               data.contacts[id] = {
                    ...(data.contacts[id] || {}),
                    ...(contact || {})
               };
               if (store && store.contacts) store.contacts[id] = {
                    ...(store.contacts?.[id] || {}),
                    ...(contact || {})
               };
          }
          writeData(data);
     });

     // Taking chats
     vikaru.ev.on("chats.upsert", (chats) => {
          const data = readData();
          chats.forEach((chat) => {
               let id = chat.id;
               data.chats[id] = {
                    ...chat
               };
               store.chats[id] = {
                    ...store.chats[id],
                    ...chat,
               };
          });
          writeData(data);
     });

     // Updating chats
     vikaru.ev.on("chats.update", (chats) => {
          const data = readData();
          chats.forEach((chat) => {
               let id = chat.id;
               data.chats[id] = {
                    ...(data.chats[id] || {}),
                    ...chat
               };
               if (store && store.chats) store.chats[id] = {
                    ...(store.chats?.[id] || {}),
                    ...(chat || {})
               };
          });
          writeData(data);
     });

     // Anti Call
     vikaru.ev.on('call', async (user) => {
          if (!setting.anticall) return
          let botNumber = await vikaru.decodeJid(vikaru.user.id)
          for (let m of user) {
               if (m.isGroup == false) {
                    if (m.status == "offer") {
                         let sendcall = await vikaru.sendMessage(m.from, {
                              text: `@${m.from.split("@")[0]} You have been blocked because you called\n\nPlease submit an unblock request if you accidentally press Call/Vc!`,
                              contextInfo: {
                                   mentionedJid: [m.from, global.devNumber],
                                   externalAdReply: {
                                        showAdAttribution: true,
                                        title: `「 🚧 」CALL DETECTED`,
                                        thumbnailUrl: 'https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg',
                                        body: "Powered By " + global.botName,
                                        //previewType: "PHOTO"
                                        mediaType: 1,
                                        renderLargerThumbnail: false
                                   }
                              }
                         });

                         let ownContact = {
                              displayName: "Contact",
                              contacts: [{
                                   displayName: devName,
                                   vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;" + devName + ";;;\nFN:" + 'Owner' + "\nitem1.TEL;waid=" + global.devNumber + ":" + global.devNumber + "\nitem1.X-ABLabel:Ponsel\nEND:VCARD"
                              }]
                         };
                         await vikaru.sendMessage(m.from, {
                              contacts: ownContact
                         }, sendcall);

                         setTimeout(() => {
                              vikaru.updateBlockStatus(m.from, "block")
                         }, 3000);
                    }
               }
          }
     });

     // Welcome
     vikaru.ev.on('group-participants.update', async (anu) => {
          const isWelcome = welcome.includes(anu.id)
          if (isWelcome) {
               try {
                    let metadata = await vikaru.groupMetadata(anu.id);
                    let participants = anu.participants;
                    for (let num of participants) {
                         try {
                              if (anu.action == 'add') {
                                   const user = num.split('@')[0];
                                   const ppUrl = await vikaru.profilePictureUrl(anu.id, "image").catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
                                   const welcomeMessage = `👋🏻 Konnichiwa @${user}\n\n${global.textWelcome}`;

                                   await vikaru.sendMessage(anu.id, {
                                        text: welcomeMessage,
                                        contextInfo: {
                                             isForwarded: true,
                                             mentionedJid: [num],
                                             forwardedNewsletterMessageInfo: {
                                                  newsletterJid: newsletter,
                                                  newsletterName: "Vikaru-Md | © Max",
                                                  serverMessageId: -1
                                             },
                                             externalAdReply: {
                                                  title: `${metadata.subject}`,
                                                  body: `${today} ▸ [ ${metadata.participants.length} Participant ]`,
                                                  thumbnailUrl: ppUrl,
                                                  sourceUrl: "",
                                                  mediaType: 1,
                                                  renderLargerThumbnail: false
                                             }
                                        }
                                   });
                                   await vikaru.sendMessage(anu.id, {
                                        audio: fs.readFileSync(`./main/media/audio/konnichiwa.mp3`),
                                        mimetype: "audio/mp4",
                                        ptt: true
                                   }, {
                                        quoted: null
                                   });
                              }
                         } catch (err) {
                              console.error(`Error processing participant update: ${err}`);
                         }
                    }
               } catch (err) {
                    console.error(`Error fetching group metadata: ${err}`);
               }
          }
     });

     // Detecting connection to server
     vikaru.ev.on('connection.update', (update) => {
          const {
               connection,
               receivedPendingNotifications,
               lastDisconnect
          } = update;

          // Connectinging
          if (connection == 'connecting') {
               console.log()
               console.log(`› [ ${chalk.black(chalk.bgWhite(' Starting Bot '))} ] ▸ Connecting To WhatsApp Server...`);

               //Connected
          } else if (connection === "open") {
               const data = readData();
               if (store && store.contacts) {
                    store.contacts = data.contacts;
               }
               if (store && store.chats) {
                    store.chats = data.chats;
               }
               console.log();
               console.log(`› [ ${chalk.black(chalk.bgGreen(' Connected To '))} ] ▸ ${vikaru.user.id}`);

               // Connection status message to dev number
               if (setting.notify) {
                    vikaru.sendMessage(devNumber + '@s.whatsapp.net', {
                         text: global.notify
                    });
               }

               // Waiting for new messages
               if (receivedPendingNotifications) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgCyanBright(' Waiting Chat '))} ] ▸ Waiting for incoming message...`);
               }

               // Disconnected
          } else if (connection === "close") {
               let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
               if (reason === DisconnectReason.badSession) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgRedBright(' Disconnected '))} ] ▸ Bad Session File, Please Delete Session and Pairing Again`);
                    process.exit();
               } else if (reason === DisconnectReason.connectionClosed) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgYellow(' Reconnecting '))} ] ▸ Connection Closed...`);
                    vikarustart(session);
               } else if (reason === DisconnectReason.connectionLost) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgYellow(' Reconnecting '))} ] ▸ Connection Lost From Server...`);
                    vikarustart(session);
               } else if (reason === DisconnectReason.connectionReplaced) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgRedBright(' Disconnected '))} ] ▸ Connection Replaced, Another New Session Opened`);
                    process.exit();
               } else if (reason === DisconnectReason.loggedOut) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgRedBright(' Disconnected '))} ] ▸ Device Logged Out, Delete "${session}" Folder and Pairing Again.`);
                    fs.rmSync(`./session/${session}`, {
                         recursive: true
                    });
                    vikarustart(session);
               } else if (reason === DisconnectReason.restartRequired) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgYellow(' Reconnecting '))} ] ▸ Restart Required...`);
                    vikarustart(session);
               } else if (reason === DisconnectReason.timedOut) {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgYellow(' Reconnecting '))} ] ▸ Connection TimedOut...`);
                    vikarustart(session);
               } else {
                    console.log()
                    console.log(`› [ ${chalk.black(chalk.bgMagenta(' Reconnecting '))} ] ▸ Unknown DisconnectReason: ${reason}|${connection}`);
                    vikarustart(session);
               }
          }
     });

     // Decode Jid user / group
     vikaru.decodeJid = (jid) => {
          if (!jid) return jid
          if (/:\d+@/gi.test(jid)) {
               let decode = jidDecode(jid) || {}
               return decode.user && decode.server && decode.user + '@' + decode.server || jid
          } else return jid
     };

     // Get subject / name from Jid
     vikaru.getName = (jid, withoutContact = false) => {
          id = vikaru.decodeJid(jid)
          withoutContact = vikaru.withoutContact || withoutContact
          let v
          if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
               v = store.contacts[id] || {}
               if (!(v.name || v.subject)) v = vikaru.groupMetadata(id) || {}
               resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
          })
          else v = id === '0@s.whatsapp.net' ? {
                    id,
                    name: 'WhatsApp'
               } : id === vikaru.decodeJid(vikaru.user.id) ?
               vikaru.user :
               (store.contacts[id] || {})
          return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
     };

     // Variable Send message for smsg
     vikaru.sendText = (jid, text, quoted = '', options) => vikaru.sendMessage(jid, {
          text: text,
          ...options
     }, {
          quoted
     });

     // Keep session always connected ( ev.on cover )
     vikaru.ev.on('creds.update', saveCreds);

     // Variable media download
     vikaru.downloadMediaMessage = async (message) => {
          let mime = (message.msg || message).mimetype || ''
          let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
          const stream = await downloadContentFromMessage(message, messageType)
          let buffer = Buffer.from([])
          for await (const chunk of stream) {
               buffer = Buffer.concat([buffer, chunk])
          }
          return buffer
     };

     // Variable media download + save
     vikaru.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
          let quoted = message.msg ? message.msg : message
          let mime = (message.msg || message).mimetype || ''
          let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
          const stream = await downloadContentFromMessage(quoted, messageType)
          let buffer = Buffer.from([])
          for await (const chunk of stream) {
               buffer = Buffer.concat([buffer, chunk])
          }
          let type = await FileType.fromBuffer(buffer)
          trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
          // save to file
          await fs.writeFileSync(trueFileName, buffer)
          return trueFileName
     };

     // Send Image stickers
     vikaru.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
          let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
          let buffer
          if (options && (options.packname || options.author)) {
               buffer = await writeExifImg(buff, options)
          } else {
               buffer = await imageToWebp(buff)
          }
          await vikaru.sendMessage(jid, {
               sticker: {
                    url: buffer
               },
               ...options
          }, {
               quoted
          })
          return buffer
     };

     // Send video stickers
     vikaru.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
          let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
          let buffer
          if (options && (options.packname || options.author)) {
               buffer = await writeExifVid(buff, options)
          } else {
               buffer = await videoToWebp(buff)
          }
          await vikaru.sendMessage(jid, {
               sticker: {
                    url: buffer
               },
               ...options
          }, {
               quoted
          })
          return buffer
     };

     // End start
     return vikaru
};


// Starting bot
(async () => {
     console.log(`

           █░█░█░█░▄▀░▄▀▄░█▀▀▄░█░█ 
           █░█░█░█▀▄░░█▀█░█▐█▀░█░█
           ░▀░░▀░▀░▀▀░▀░▀░▀░▀▀░▀▀▀
`);
     console.log('=-------------------------------------------=\n      Vikaru-Md      |       dcodemaxz\n=-------------------------------------------=');

     // Fungsi untuk memeriksa keberadaan folder dan file
     function checkDependencies() {
          const nodeModulesPath = path.join(__dirname, 'node_modules');
          const licensePath = path.join(__dirname, '© dcodemaxz');

          if (!fs.existsSync(nodeModulesPath)) {
               console.log();
               console.log(' • Please install the module first  [ npm install ].');
               return false;
          }

          if (!fs.existsSync(licensePath)) {
               console.log();
               console.error(' • Watermark detected has been removed!');
               return false;
          }

          return true;
     }

     if (!checkDependencies()) {
          process.exit(1); // Keluar dengan kode error
     }

     await vikarustart(); // Start
})();


// Refreshing File After Recode/Editing
let file = require.resolve(__filename)
fs.watchFile(file, () => {
     fs.unwatchFile(file)
     console.log()
     console.log(`› [ ${chalk.black(chalk.bgBlue(' Update Files '))} ] ▸ index.js = Plaease Restart Bot!`)
     process.exit(); // Exit ( options )
     delete require.cache[file]
     require(file)
});